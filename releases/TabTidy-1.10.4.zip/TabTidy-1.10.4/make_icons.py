"""
TabTidy 图标生成器 —— Smartisan OS 轻拟物风格

设计依据：docs/smartisan-redesign.md
图标和界面用**同一套材质语言**，取值全部来自 smartisan.css：

  1. 超椭圆底盘，填充套件主蓝（Background/Button/Primary/Enabled）的
     `#5b87eb → #5883eb` —— 注意这是**同色系 2% 明度差**，不是跨色相渐变。
     锤子的渐变只用来做光照感，不做色彩。
  2. 0.8px 描边在图标尺寸下会消失，所以按比例放大成约 2% 边长，取 `#3f68e2`。
  3. 顶部一道极淡的内高光（对应套件的 `inset 0 1px 0 rgba(255,255,255,.38)`）。
  4. 三根**横向**白色玻璃条，长度错落（中间最长），用 `#ffffff → #f2f4f8` 的微渐变，
     底下投一层柔和阴影。
  5. **没有**高饱和多色渐变、镜面高光、边缘光、颗粒 —— 那些是液态玻璃的语言。

纯标准库（math + zlib + struct）。
768×768 母版 → 整数倍箱式降采样到 128 / 48 / 32 / 16。

用法： python make_icons.py
"""

import math
import os
import struct
import zlib

MASTER = 768
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icons')

# ---------------------------------------------------------------- 设计参数（取值来自套件）

BLUE_TOP = (0x5b, 0x87, 0xeb)      # --s-grad-primary 起点
BLUE_BOT = (0x58, 0x83, 0xeb)      # --s-grad-primary 终点
BORDER = (0x35, 0x59, 0xd6)        # 套件主按钮描边色再压深一档（#3f68e2 在图标尺寸下看不出边界）
BAR_TOP = (0xff, 0xff, 0xff)       # --s-grad-white
BAR_BOT = (0xfb, 0xfc, 0xfe)

SQ_P = 4.4                         # 超椭圆指数
FEATHER = 1.1                      # 母版上的柔化（其余交给降采样）
BORDER_W = 0.024                   # 描边宽度（占**边长**比例）：128px 上约 3px
HILITE = 0.16                      # 顶部内高光强度（对应套件那条 inset 白线）

# 三根横向玻璃条
BAR_H, BAR_GAP = 0.170, 0.056
BAR_WIDTHS = (0.470, 0.610, 0.385)
BAR_RADIUS_RATIO = 0.40
BAR_SHADOW_DY = 0.016


def clamp(v, lo=0.0, hi=1.0):
    return lo if v < lo else (hi if v > hi else v)


def smoothstep(e0, e1, x):
    t = clamp((x - e0) / (e1 - e0))
    return t * t * (3.0 - 2.0 * t)


def lerp(a, b, t):
    return a + (b - a) * t


def lerp3(c0, c1, t):
    return (lerp(c0[0], c1[0], t), lerp(c0[1], c1[1], t), lerp(c0[2], c1[2], t))


def build_bars():
    """三根横条的圆角矩形参数；整块居中，纵向等距，长度错落，左对齐。"""
    total_h = BAR_H * 3 + BAR_GAP * 2
    top = (1.0 - total_h) / 2.0
    left = (1.0 - max(BAR_WIDTHS)) / 2.0
    bars = []
    y = top
    for w in BAR_WIDTHS:
        r = BAR_H * BAR_RADIUS_RATIO
        bars.append({
            'cx': left + w / 2.0,
            'cy': y + BAR_H / 2.0,
            'hw': w / 2.0 - r,
            'hh': BAR_H / 2.0 - r,
            'r': r,
        })
        y += BAR_H + BAR_GAP
    return bars, top, total_h


BARS, BAR_BLOCK_TOP, BAR_BLOCK_H = build_bars()


def render_master(n):
    half = n / 2.0
    inv = 1.0 / n

    # 超椭圆的 |u|^p 只跟 x 有关、|v|^p 只跟 y 有关 → 预计算成表
    up = [abs((i + 0.5) * inv - 0.5) ** SQ_P * (2.0 ** SQ_P) for i in range(n)]
    vp = [abs((j + 0.5) * inv - 0.5) ** SQ_P * (2.0 ** SQ_P) for j in range(n)]

    feather = FEATHER / half
    cut = 1.0 + feather * 1.6
    # ⚠️ 换算要小心：s = u^p，而 u = 1 - δ 时 1-s ≈ p·δ。
    # 这里的 δ 是"占**半宽**的比例"，而 BORDER_W 是"占**边长**的比例"，
    # 两者差一个 2 —— 漏掉这个 2，描边就会细到完全渲染不出来（踩过）。
    band = 2.0 * BORDER_W * SQ_P
    band_hi = band * 0.25

    rows = []
    for j in range(n):
        vpj = vp[j]
        y = (j + 0.5) * inv
        row = bytearray()
        for i in range(n):
            x = (i + 0.5) * inv
            s = up[i] + vpj

            if s > cut:
                row += b'\x00\x00\x00\x00'
                continue

            cov = clamp((1.0 - s) / feather + 0.5)

            # ---- 底盘：同色系自上而下的微渐变（对应 --s-grad-primary）
            r, g, b = lerp3(BLUE_TOP, BLUE_BOT, clamp(y))

            # ---- 描边：贴着轮廓的一圈，颜色取 --s-blue-500
            t_edge = smoothstep(1.0 - band, 1.0 - band_hi, s)
            if t_edge > 0.001:
                r = lerp(r, BORDER[0], t_edge)
                g = lerp(g, BORDER[1], t_edge)
                b = lerp(b, BORDER[2], t_edge)

            # ---- 顶部极淡的内高光（对应 inset 0 1px 0 rgba(255,255,255,.38)）
            if y < 0.16:
                w = (1.0 - smoothstep(0.0, 0.16, y)) * HILITE * (1.0 - t_edge)
                r += (255 - r) * w
                g += (255 - g) * w
                b += (255 - b) * w

            # ---- 玻璃条 + 条下方投影
            bar = 0.0
            shade = 0.0
            for d in BARS:
                ax = abs(x - d['cx']) - d['hw']
                if ax < 0.0:
                    ax = 0.0
                ay = abs(y - d['cy']) - d['hh']
                if ay < 0.0:
                    ay = 0.0
                dist = math.sqrt(ax * ax + ay * ay) - d['r']
                if dist < 0.10 and bar < 1.0:
                    c = clamp(0.5 - dist / 0.035)
                    if c > bar:
                        bar = c

                sy = abs(y - BAR_SHADOW_DY - d['cy']) - d['hh']
                if sy < 0.0:
                    sy = 0.0
                sdist = math.sqrt(ax * ax + sy * sy) - d['r']
                if sdist < 0.10 and shade < 1.0:
                    c = clamp(0.5 - sdist / 0.075)
                    if c > shade:
                        shade = c

            if shade > 0.001:
                dk = shade * 0.16
                r *= (1.0 - dk)
                g *= (1.0 - dk)
                b *= (1.0 - dk)

            if bar > 0.001:
                # 条本身也是同色系微渐变：#fff → #f2f4f8
                lv = clamp((y - BAR_BLOCK_TOP) / BAR_BLOCK_H)
                br, bg, bb = lerp3(BAR_TOP, BAR_BOT, lv)
                a = bar
                r += (br - r) * a
                g += (bg - g) * a
                b += (bb - b) * a

            row += bytes((
                int(clamp(r, 0.0, 255.0)),
                int(clamp(g, 0.0, 255.0)),
                int(clamp(b, 0.0, 255.0)),
                int(round(255 * cov)),
            ))
        rows.append(bytes(row))
    return rows


def downsample(rows, master, size):
    """
    整数倍箱式降采样。注意坐标：目标像素 (ox, oy) 对应源图里 step×step 的方块，
    横跨 step 行、每行再横跨 step 列。源行是一维字节串，列偏移必须是 i*4。
    """
    step = master // size
    area = step * step
    out = bytearray()
    for oy in range(size):
        out.append(0)
        for ox in range(size):
            pr = pg = pb = pa = 0
            for j in range(oy * step, (oy + 1) * step):
                row = rows[j]
                for i in range(ox * step, (ox + 1) * step):
                    p = i * 4
                    a = row[p + 3]
                    pr += row[p] * a
                    pg += row[p + 1] * a
                    pb += row[p + 2] * a
                    pa += a
            if pa == 0:
                out += b'\x00\x00\x00\x00'
            else:
                out += bytes((
                    min(255, pr // pa),
                    min(255, pg // pa),
                    min(255, pb // pa),
                    min(255, pa // area),
                ))
    return bytes(out)


def write_png(path, size, raw):
    def chunk(tag, data):
        return (struct.pack('>I', len(data)) + tag + data
                + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff))
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n')
        f.write(chunk(b'IHDR', struct.pack('>IIBBBBB', size, size, 8, 6, 0, 0, 0)))
        f.write(chunk(b'IDAT', zlib.compress(raw, 9)))
        f.write(chunk(b'IEND', b''))


def main():
    os.makedirs(OUT, exist_ok=True)
    print('渲染母版 %dx%d ...' % (MASTER, MASTER))
    rows = render_master(MASTER)
    for size in (128, 48, 32, 16):
        assert MASTER % size == 0, size
        raw = downsample(rows, MASTER, size)
        path = os.path.join(OUT, 'icon%d.png' % size)
        write_png(path, size, raw)
        print('  icon%-4d %6d bytes' % (size, os.path.getsize(path)))


if __name__ == '__main__':
    main()
