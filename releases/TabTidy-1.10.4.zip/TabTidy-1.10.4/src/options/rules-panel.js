// 「让分组听你的」面板 —— 内嵌在设置页里的模态弹窗。
//
// 之前是单独开一个标签页，会把用户从设置页里拽出去。现在改成原生 <dialog> 模态：
// 停留在当前页面、支持 ESC 关闭、自带焦点陷阱，也不会丢失设置页的滚动位置。
//
// 这个面板不做任何评测——没有准确度指标、没有算法对比、没有数据集。
// 它只有一件事：让你告诉扩展「这个网站应该归到哪一组」，然后写进规则库。

const CHECK = '\u2713';

/**
 * @param {object} deps
 * @param {HTMLDialogElement} deps.dialog  承载面板的 <dialog>
 * @param {(type: string, payload?: object, timeoutMs?: number) => Promise<any>} deps.send
 * @param {(msg: string) => void} deps.toast
 * @param {() => void} [deps.onChanged]    规则写入后回调，用来刷新设置页的规则表
 */
export function createRulesPanel({ dialog, send, toast, onChanged }) {
  const q = (name) => dialog.querySelector('[data-rp="' + name + '"]');

  let tabs = [];
  let predGroups = [];      // 当前分组结果，只用于"现在分在哪"参考列和预填
  const truth = {};         // tabId -> 组名（工作副本）
  let truthByUrl = {};      // url -> 组名（持久化副本）
  let saveTimer = null;
  let loadedOnce = false;

  // ------------------------------------------------------------ 标注持久化

  function syncTruthByUrl() {
    const map = {};
    for (const t of tabs) {
      const name = truth[t.id];
      if (name) map[t.url] = name;
    }
    truthByUrl = map;
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      saveTimer = null;
      send('SAVE_TRUTH', { truth: truthByUrl }).catch(() => { /* 存不上不影响使用 */ });
    }, 400);
  }

  function applyTruthFromUrl() {
    for (const t of tabs) {
      if (!truth[t.id] && truthByUrl[t.url]) truth[t.id] = truthByUrl[t.url];
    }
  }

  // ------------------------------------------------------------ 标注行
  //
  // 原来是 5 列表格。套件里没有表格组件，而"左侧描述 + 右侧控件"正是列表行的
  // 标准形态，所以改成列表行：色点 + 标题 + 「网站 · 现在分在哪」+ 右侧输入框。
  // 好处是中文标题不必再挤在窄列里被截断。

  function renderRows() {
    const wrap = q('wrap');
    if (!tabs.length) {
      wrap.innerHTML = '<div class="rp-empty">没有可标注的标签页。</div>';
      updateStat();
      return;
    }
    applyTruthFromUrl();

    const predOf = new Map();
    predGroups.forEach((g) => g.tabIds.forEach((id) => predOf.set(id, g)));

    const dl = document.createElement('datalist');
    dl.id = 'rpTruthList';
    const names = new Set(Object.values(truth).filter(Boolean));
    predGroups.forEach((g) => names.add(g.name));
    for (const n of names) {
      const o = document.createElement('option');
      o.value = n;
      dl.appendChild(o);
    }

    wrap.innerHTML = '';
    wrap.appendChild(dl);

    tabs.forEach((t) => {
      const row = document.createElement('div');
      row.className = 's-list-item anno';

      const g = predOf.get(t.id);

      const dot = document.createElement('span');
      dot.className = 'popup__dot popup__dot--' + ((g && g.color) || 'grey');
      row.appendChild(dot);

      const text = document.createElement('div');
      text.className = 's-list-item__text';
      const title = document.createElement('div');
      title.className = 's-list-item__title';
      title.textContent = t.title || t.url;
      title.title = t.url + '\n（点一下跳到这个标签页）';
      const sub = document.createElement('div');
      sub.className = 's-list-item__subtitle';
      // 显示**主机名**而不是归并后的域名 —— mail.qq.com 和 weixin.qq.com 必须一眼能区分
      sub.textContent = (t.host || t.domain) + ' · 现在：' + (g ? g.name : '—');
      text.append(title, sub);
      text.style.cursor = 'pointer';
      text.addEventListener('click', async () => {
        try {
          await chrome.tabs.update(t.id, { active: true });
          const tab = await chrome.tabs.get(t.id);
          await chrome.windows.update(tab.windowId, { focused: true });
        } catch (err) { toast('标签页已关闭'); }
      });
      row.appendChild(text);

      const inp = document.createElement('input');
      inp.className = 's-textfield anno__input';
      inp.type = 'text';
      inp.placeholder = '填组名';
      inp.setAttribute('list', 'rpTruthList');
      inp.value = truth[t.id] || '';
      inp.addEventListener('input', () => {
        if (inp.value.trim()) truth[t.id] = inp.value.trim();
        else delete truth[t.id];
        updateStat();
        syncTruthByUrl();
      });
      row.appendChild(inp);

      wrap.appendChild(row);
    });
    updateStat();
  }

  function updateStat() {
    const done = Object.keys(truth).length;
    const total = tabs.length;
    const distinct = new Set(Object.values(truth)).size;
    q('stat').textContent = total
      ? `已标注 ${done} / ${total}${distinct ? `，共 ${distinct} 组` : ''}`
      : '';
  }

  // ------------------------------------------------------------ 操作

  async function reload() {
    const wrap = q('wrap');
    wrap.innerHTML = '<div class="rp-empty">正在载入…</div>';
    try {
      const res = await send('PREVIEW', { strategy: 'hybrid', overrides: {} });
      tabs = res.tabs || [];
      predGroups = res.groups || [];
      // 清掉已关闭标签页的标注，避免脏数据
      const live = new Set(tabs.map((t) => t.id));
      for (const k of Object.keys(truth)) if (!live.has(Number(k))) delete truth[k];
      renderRows();
    } catch (e) {
      wrap.innerHTML = `<div class="rp-empty">载入失败：${e.message}</div>`;
    }
  }

  function fillFromCurrent() {
    if (!predGroups.length) return toast('还没有分组结果，先点「重新载入」');
    predGroups.forEach((g) => g.tabIds.forEach((id) => { truth[id] = g.name; }));
    renderRows();
    syncTruthByUrl();
    toast('已用现在的分组预填，把不对的地方改掉就行');
  }

  async function clearTruth() {
    for (const k of Object.keys(truth)) delete truth[k];
    truthByUrl = {};
    await send('CLEAR_TRUTH', {}).catch(() => {});
    renderRows();
    q('result').innerHTML = '';
    toast('已清空标注');
  }

  /** 把"每个标签页 → 你给的组名"按网站汇总，同一网站以最后一次为准 */
  function buildRuleEntries() {
    const byDomain = new Map();
    for (const t of tabs) {
      const name = truth[t.id];
      if (!name) continue;
      // 规则按主机名记：给 weixin.qq.com 标规则，绝不该波及 mail.qq.com
      const key = t.host || t.domain;
      byDomain.set(key, { domain: key, group: name });
    }
    return [...byDomain.values()];
  }

  async function importRules() {
    const entries = buildRuleEntries();
    if (!entries.length) {
      return toast('还没有标注。先在第 1 步填「应该属于哪一组」');
    }
    const btn = q('import');
    btn.disabled = true;
    try {
      const res = await send('IMPORT_TRUTH', {
        entries,
        overwrite: q('overwrite').checked
      });

      const parts = [];
      if (res.added) parts.push(`新增 <b>${res.added}</b> 条`);
      if (res.updated) parts.push(`更新 <b>${res.updated}</b> 条`);
      if (res.unchanged) parts.push(`无变化 <b>${res.unchanged}</b> 条`);
      if (res.skipped) parts.push(`跳过 <b>${res.skipped}</b> 条`);

      let html = `<div class="rp-note">
        <strong>规则已写入。</strong>${parts.join('，')}。<br>
        下次点「智能分组」时就会按这些规则来。
      </div>`;

      if (res.learningWasOff) {
        html += `<div class="rp-note warn">
          「记住我的分组习惯」原本是关的，已自动打开——否则这些规则不会被使用。
        </div>`;
      }

      if (res.tooSmall && res.tooSmall.length) {
        const list = res.tooSmall.map((x) => `「${x.name}」(${x.tabs} 个)`).join('、');
        html += `<div class="rp-note warn">
          这些组目前<strong>不会立刻成组</strong>：${list}。
          因为「每组最少标签页数」是 <b>${res.minTabsPerGroup}</b>，组内标签页不够。
          想让它生效，到「高级设置」把这个值调小。
        </div>`;
      }

      if (res.rejected && res.rejected.length) {
        const rows = res.rejected.slice(0, 12)
          .map((r) => `<tr><td class="mono">${r.domain || '—'}</td><td>${r.group || '—'}</td><td class="faint">${r.why}</td></tr>`)
          .join('');
        html += `<div class="rp-note warn">
          <strong>被跳过 ${res.rejected.length} 条：</strong>
          <table class="rule-table"><thead><tr><th>网站</th><th>组名</th><th>原因</th></tr></thead><tbody>${rows}</tbody></table>
        </div>`;
      }

      q('result').innerHTML = html;
      toast(CHECK + ' 规则已写入');
      if (typeof onChanged === 'function') onChanged();
    } catch (e) {
      q('result').innerHTML = `<div class="rp-note warn">写入失败：${e.message}</div>`;
    } finally {
      btn.disabled = false;
    }
  }

  // ------------------------------------------------------------ 打开 / 关闭

  async function open() {
    if (dialog.open) return;                 // showModal() 对已打开的 dialog 会抛错
    // 首次打开时取回上次的标注（按网址存）
    if (!loadedOnce) {
      loadedOnce = true;
      try {
        const res = await send('GET_TRUTH', {});
        truthByUrl = res.truth || {};
      } catch (e) { /* 拿不到就当没有 */ }
    }
    q('result').innerHTML = '';
    dialog.showModal();
    await reload();
  }

  function close() {
    if (dialog.open) dialog.close();
  }

  // ------------------------------------------------------------ 事件绑定

  q('reload').addEventListener('click', reload);
  q('fill').addEventListener('click', fillFromCurrent);
  q('clear').addEventListener('click', clearTruth);
  q('import').addEventListener('click', importRules);
  q('closeFoot').addEventListener('click', close);

  // 点遮罩关闭：<dialog> 的点击目标是 dialog 本身时说明点在内容之外
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) close();
  });

  return { open, close };
}
