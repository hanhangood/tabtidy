// Service Worker：消息路由 + 分组落地 + 「让分组听你的」规则

import { collectTabs, runStrategy, groupHybrid, assignUniqueColors, applyGroupOrder } from './lib/grouping.js';
import {
  getSettings, saveSettings, getLearning, clearLearning, recordCorrection,
  applyLearned, sanitizeLearning, isLearnableName, importTruthAsRules,
  getTruthByUrl, saveTruthByUrl, clearTruthByUrl,
  getGroupOrder, saveGroupOrder, deleteRules
} from './lib/storage.js';
import {
  rememberMovedByUs, rememberTitledByUs, wasMovedByUs, wasTitledByUs,
  getKnownTitle, setKnownTitle, forgetTab, isDomainLikeTitle
} from './lib/selfactions.js';
import { rootDomain, hostOf } from './lib/text.js';
import { buildMovePlan } from './lib/move.js';
import { syncStatus, syncRun } from './lib/sync.js';

// ---------------------------------------------------------------- 自动同步
//
// 触发点有三个，都走 hash 去重，所以随便触发也不会产生无谓写入：
//   1. 本机数据变了（settings / learning / evalTruth 任一被写）
//   2. 云端被别的设备改了（sync 区 tt1_meta 变化）
//   3. SW 被唤醒 / 浏览器启动
//
// 注意 `_syncTimer` / `_syncRunning` 是模块级变量，SW 回收后会清零 ——
// 这没关系：它们只是防抖和重入保护，丢了对正确性没有影响。

const SYNC_DEBOUNCE = 800;

let _syncTimer = null;
let _syncRunning = false;

function scheduleSync(delay = SYNC_DEBOUNCE) {
  if (_syncTimer) clearTimeout(_syncTimer);
  _syncTimer = setTimeout(() => {
    _syncTimer = null;
    runSync().catch((e) => console.warn('[TabTidy] 自动同步失败', e));
  }, delay);
}

async function runSync(force = false) {
  if (_syncRunning) return null;
  _syncRunning = true;
  try {
    return await syncRun({ force });
  } finally {
    _syncRunning = false;
  }
}

try {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      // 本机数据变了 → 往外推
      if (changes.settings || changes.learning || changes.evalTruth || changes.truthUpdatedAt) {
        scheduleSync();
      }
      return;
    }
    if (areaName === 'sync' && changes.tt1_meta) {
      // 云端变了 → 拉回来合并。自己写的也会触发一次，
      // 但下次 syncRun 会发现本地和云端内容一致，直接返回，不会写任何东西。
      scheduleSync();
    }
  });
} catch (e) { /* 非扩展环境忽略 */ }

try {
  chrome.runtime.onStartup.addListener(() => scheduleSync(0));
  chrome.runtime.onInstalled.addListener(() => scheduleSync(0));
} catch (e) { /* 忽略 */ }

// ---------------------------------------------------------------- 顺序记忆：原生标签栏拖动
//
// 用户除了在弹窗里拖，也可能直接在浏览器的标签栏里把某个分组拖到最前面。
// 那种拖动不会经过我们的界面，所以要监听 tabGroups.onMoved 再记一遍。
//
// 难点：chrome.tabGroups 的 Group 对象**没有 index 字段**（只有 Tab 有）。
// 好在同一组的标签页在标签栏里是连续的，所以「组的位置 = 组内标签页的最小 index」。
//
// 我们自己分组时会新建组、也会挪标签页，这些不该被当成"用户调整了顺序"，
// 所以 organizing 期间直接跳过。

// 我们自己排顺序时，不要把它当成"用户手动调整了顺序"
let reorderingNative = false;

async function rememberNativeOrder(windowId) {
  const [groups, tabs] = await Promise.all([
    chrome.tabGroups.query({ windowId }),
    chrome.tabs.query({ windowId })
  ]);
  if (!groups.length) return;

  const titleOf = new Map(groups.map((g) => [g.id, g.title || '']));
  const firstIndex = new Map();
  for (const t of tabs) {
    if (t.groupId == null || t.groupId < 0) continue;
    const cur = firstIndex.get(t.groupId);
    if (cur === undefined || t.index < cur) firstIndex.set(t.groupId, t.index);
  }

  const names = [...firstIndex.entries()]
    .sort((a, b) => a[1] - b[1])
    .map(([groupId]) => (titleOf.get(groupId) || '').trim())
    .filter(Boolean);

  if (names.length < 2) return;     // 只有一个组时"顺序"没有意义
  await saveGroupOrder(names);
}

try {
  if (chrome.tabGroups && chrome.tabGroups.onMoved) {
    chrome.tabGroups.onMoved.addListener((group) => {
      if (organizing || reorderingNative) return;   // 我们自己挪的，不算用户调整
      rememberNativeOrder(group.windowId).catch((e) => console.warn('[TabTidy] 记录分组顺序失败', e));
    });
  }
} catch (e) { /* 老版本浏览器没有 onMoved，忽略即可 */ }

/**
 * 让浏览器标签栏里的分组顺序也按 names 排。
 *
 * 为什么必须单独做：`applyGroups` 是**幂等**的 —— 标签页已经在正确的组里就什么都不做，
 * 所以它只决定"新建组的先后"，从不动已有组的位置。而弹窗里的列表是我们自己按记忆排的，
 * 两者数据来源不同，不主动对齐就会一直不一致（弹窗显示对、标签栏没变）。
 *
 * Chrome 没有"设置组序号"的 API，只能把组搬到某个 tab 下标上，所以按计划逐个搬。
 * 具体搬哪些由 lib/move.js 的 buildMovePlan 算（那部分是可以单测的纯逻辑）。
 */
async function applyNativeGroupOrder(windowId, names) {
  if (!chrome.tabGroups || typeof chrome.tabGroups.move !== 'function') {
    return { moved: 0, skipped: 'unsupported' };
  }

  let wId = windowId;
  if (wId == null || wId === CURRENT_WINDOW) {
    try {
      const win = await chrome.windows.getLastFocused({ populate: false });
      wId = win && win.id;
    } catch (e) { wId = null; }
  }
  if (wId == null) return { moved: 0, skipped: 'no-window' };

  let groups;
  let tabs;
  try {
    [groups, tabs] = await Promise.all([
      chrome.tabGroups.query({ windowId: wId }),
      chrome.tabs.query({ windowId: wId })
    ]);
  } catch (e) {
    return { moved: 0, skipped: 'query-failed' };
  }
  if (!groups || groups.length < 2) return { moved: 0 };

  const { steps } = buildMovePlan(groups, tabs || [], names || []);
  if (!steps.length) return { moved: 0 };

  reorderingNative = true;
  let moved = 0;
  try {
    for (const st of steps) {
      try {
        await withTimeout(chrome.tabGroups.move(st.id, { index: st.index }), 4000, '排列分组');
        moved++;
      } catch (e) {
        console.warn('[TabTidy] 排列分组失败', st.id, e);
      }
    }
  } finally {
    reorderingNative = false;
  }
  return { moved };
}

const CURRENT_WINDOW = chrome.windows.WINDOW_ID_CURRENT;
const TAB_GROUP_NONE = -1;

// 我们自己执行分组时，短时间内忽略标签页变化。
// 注意这只是**快路径优化**，真正的判据是 selfactions.js 里的状态比对——
// Service Worker 空闲约 30 秒就被回收，模块变量会清零，靠它单独判断会误学。
let selfActingUntil = 0;
const markSelfActing = () => { selfActingUntil = Date.now() + 8000; };
const isSelfActing = () => Date.now() < selfActingUntil;

// 同一时刻只允许一个分组任务在跑
let organizing = false;

chrome.runtime.onInstalled.addListener((details) => {
  sanitizeLearning().catch(() => {});
  if (details.reason === 'install') chrome.runtime.openOptionsPage();
});

// SW 每次被唤醒也顺手清理一次，保证历史脏数据不会一直影响分组
sanitizeLearning().catch(() => {});

// ------------------------------------------------------------ 工具

/** 给任何 Promise 加超时。Chrome 的 tabGroups / tabs API 偶发不回调，没有这个就会永久卡住。 */
function withTimeout(promise, ms, label) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(label + ' 超时（' + ms + 'ms）')), ms);
    Promise.resolve(promise).then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); }
    );
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ------------------------------------------------------------ 落地分组

/**
 * 把分组结果应用到浏览器原生标签组。
 *
 * 关键设计：**幂等**。
 * 第一次分组后标签页已经在组里了，第二次再点不应该把标签页搬来搬去
 * （搬动会让弹窗失焦关闭，也容易和 tabGroups.update 抢状态导致卡死）。
 * 所以这里先做快照，凡是"已经待在正确组里"的直接跳过，不对它调任何写 API。
 *
 * @returns {{applied: Array, alreadyOk: Array, failed: Array}}
 */
export async function applyGroups(groups, opts = {}) {
  const { keepExisting = true, collapse = false, windowId, skipMisc = false } = opts;
  // 归一化：-2 (WINDOW_ID_CURRENT) 和 undefined 都当作"当前窗口"，不能直接塞进 windowId 过滤器
  const wId = (windowId == null || windowId === CURRENT_WINDOW) ? null : windowId;
  markSelfActing();

  const existing = await chrome.tabGroups.query(wId != null ? { windowId: wId } : {});
  const byTitle = new Map();
  for (const tg of existing) {
    if (tg.title) byTitle.set(tg.title, tg);
  }

  if (!keepExisting) {
    const autoTitles = new Set(groups.map((g) => g.name));
    for (const tg of existing) {
      if (!autoTitles.has(tg.title)) continue;
      const tabs = await chrome.tabs.query({ groupId: tg.id });
      if (tabs.length) await chrome.tabs.ungroup(tabs.map((t) => t.id));
      byTitle.delete(tg.title);
    }
    markSelfActing();
  }

  const applied = [];
  const alreadyOk = [];
  const failed = [];
  // 记下"我们做了什么"，供学习监听器比对。
  // 落到 storage.session 而不是模块变量，这样 Service Worker 被回收重启后依然认得出来。
  const movedByUs = {};
  const titledByUs = {};
  const note = (tabIds, groupId, title) => {
    for (const id of tabIds) movedByUs[id] = groupId;
    titledByUs[groupId] = title;
  };

  for (const g of groups) {
    if (skipMisc && g.source === 'misc') continue;
    const title = (g.name || '未命名').slice(0, 32);
    const wantColor = g.color || 'grey';
    const wantCollapsed = !!collapse;

    const live = [];
    const currentGroups = new Set();
    for (const id of g.tabIds || []) {
      try {
        const t = await chrome.tabs.get(id);
        live.push(id);
        currentGroups.add(t.groupId == null ? TAB_GROUP_NONE : t.groupId);
      } catch (e) { /* 标签页已关闭 */ }
    }
    if (!live.length) continue;

    const reuse = byTitle.get(title);

    // 幂等快路径：这批标签页全部已经待在目标组里 → 一个写 API 都不调，直接跳过。
    // 这是"第二次点击智能分组"能瞬间完成、且不再卡住的原因。
    if (reuse && live.length === (g.tabIds || []).length
        && currentGroups.size === 1 && currentGroups.has(reuse.id)) {
      const sameLook = reuse.color === wantColor && reuse.collapsed === wantCollapsed;
      if (sameLook) {
        alreadyOk.push({ name: title, groupId: reuse.id, count: live.length });
        note(live, reuse.id, title);
        continue;
      }
      try {
        await withTimeout(chrome.tabGroups.update(reuse.id, {
          title, color: wantColor, collapsed: wantCollapsed
        }), 8000, '更新组「' + title + '」外观');
        alreadyOk.push({ name: title, groupId: reuse.id, count: live.length });
        note(live, reuse.id, title);
      } catch (e) {
        failed.push({ name: title, error: String(e.message || e) });
      }
      continue;
    }

    let groupId;
    try {
      if (reuse) {
        groupId = await withTimeout(
          chrome.tabs.group({ tabIds: live, groupId: reuse.id }),
          8000, '把标签页移入「' + title + '」'
        );
      } else {
        groupId = await withTimeout(
          chrome.tabs.group({
            tabIds: live,
            ...(wId != null ? { createProperties: { windowId: wId } } : {})
          }),
          8000, '新建标签组「' + title + '」'
        );
      }
    } catch (e) {
      console.warn('[TabTidy] 建组失败', title, e);
      failed.push({ name: title, error: String(e.message || e) });
      continue;
    }

    // 组可能因为成员被搬空而被浏览器自动删掉，所以更新属性单独兜一层错误
    try {
      await withTimeout(chrome.tabGroups.update(groupId, {
        title, color: wantColor, collapsed: wantCollapsed
      }), 8000, '设置「' + title + '」的标题与颜色');
      const fresh = await chrome.tabGroups.get(groupId).catch(() => null);
      if (fresh) byTitle.set(title, fresh);
    } catch (e) {
      console.warn('[TabTidy] 更新组属性失败', title, e);
      failed.push({ name: title, error: '设置属性失败：' + String(e.message || e) });
    }

    applied.push({ name: title, groupId, count: live.length });
    note(live, groupId, title);
    markSelfActing();

    // 让出主线程，避免一次性几百个 chrome API 调用把消息回执挤到超时之后
    await sleep(0);
  }

  // 落盘"我们做过什么"。即使此刻 Service Worker 被回收，下一轮也还能靠它认出自己的操作。
  await rememberMovedByUs(movedByUs).catch(() => {});
  await rememberTitledByUs(titledByUs).catch(() => {});

  // 让标签栏里的分组顺序也跟这次分组结果一致。
  // 幂等逻辑只会新建组、不会挪已有组，不主动对齐的话两边的顺序会越走越散。
  await applyNativeGroupOrder(wId, groups.map((g) => g.name)).catch(() => {});

  return { applied, alreadyOk, failed };
}

// ------------------------------------------------------------ 页面内容补全

const META_FN = () => {
  const pick = (sel) => {
    const el = document.querySelector(sel);
    return el ? (el.getAttribute('content') || '') : '';
  };
  const headings = Array.from(document.querySelectorAll('h1, h2'))
    .slice(0, 6).map((h) => (h.textContent || '').trim()).join(' ');
  return {
    title: document.title,
    desc: pick('meta[name="description"]') || pick('meta[property="og:description"]'),
    keywords: pick('meta[name="keywords"]') || pick('meta[property="article:tag"]'),
    headings
  };
};

const META_CACHE_MAX = 600;

/**
 * 抓取页面 meta 信息并写入 metaCache（按 URL 存）。
 *
 * 几个必须遵守的约束，否则会把整个分组流程拖死：
 * 1. **绝不碰睡眠/被丢弃的标签页**（t.discarded）。对它调 executeScript 会先唤醒并重新加载，
 *    一次要好几秒——这正是早期"卡在正在分组…"的原因。
 * 2. **跳过正在加载中的页面**（status === 'loading'），注入会排队等它加载完。
 * 3. **每个页面单独超时**，任何一个页面不回来都只是跳过它。
 * 4. **有总时间预算**，超了就带着已有结果返回。
 * 5. 只处理 http/https，edge:// chrome:// 扩展页 PDF 一律跳过。
 */
async function runDeepAnalyze(tabIds, { requirePermission = true, perTabMs = 2500, budgetMs = 45000 } = {}) {
  const has = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
  if (!has) {
    if (requirePermission) throw new Error('尚未授予"读取网页内容"权限');
    return { results: [], analyzed: 0, skipped: 0, reason: 'no-permission' };
  }

  const all = await chrome.tabs.query({});
  const wanted = new Set(tabIds || []);
  const candidates = tabIds ? all.filter((t) => wanted.has(t.id)) : all;

  const targets = [];
  const skippedList = [];
  for (const t of candidates) {
    const url = t.url || '';
    if (!/^https?:/i.test(url)) { skippedList.push({ id: t.id, why: '非网页' }); continue; }
    if (t.discarded) { skippedList.push({ id: t.id, why: '睡眠中，不唤醒' }); continue; }
    if (t.status === 'loading') { skippedList.push({ id: t.id, why: '加载中' }); continue; }
    targets.push(t);
    if (targets.length >= 100) break;
  }

  const started = Date.now();
  const results = [];
  const pending = [];

  // 每处理几个页面就落一次盘。这样即使 Service Worker 中途被回收，已抓到的内容也不会白费。
  const flush = async () => {
    if (!pending.length) return;
    const { metaCache = {} } = await chrome.storage.local.get('metaCache');
    for (const r of pending) {
      if (r.error || !r.url) continue;
      metaCache[r.url] = r;
    }
    pending.length = 0;
    const keys = Object.keys(metaCache);
    if (keys.length > META_CACHE_MAX) {
      keys.sort((a, b) => (metaCache[a].at || 0) - (metaCache[b].at || 0));
      for (const k of keys.slice(0, keys.length - META_CACHE_MAX)) delete metaCache[k];
    }
    await chrome.storage.local.set({ metaCache });
    return Object.keys(metaCache).length;
  };

  for (const t of targets) {
    if (Date.now() - started > budgetMs) {
      results.push({ tabId: t.id, url: t.url, error: '超出时间预算，已跳过' });
      continue;
    }
    try {
      const [r] = await withTimeout(
        chrome.scripting.executeScript({ target: { tabId: t.id }, func: META_FN }),
        perTabMs, '读取「' + (t.title || '').slice(0, 20) + '」的页面内容'
      );
      const item = { tabId: t.id, url: t.url, at: Date.now(), ...(r && r.result ? r.result : {}) };
      results.push(item);
      pending.push(item);
    } catch (e) {
      results.push({ tabId: t.id, url: t.url, error: String(e.message || e) });
    }
    if (pending.length >= 5) await flush();
  }
  const cached = await flush();

  return {
    results,
    analyzed: results.filter((r) => !r.error).length,
    failed: results.filter((r) => r.error).length,
    skipped: skippedList.length,
    skippedDetail: skippedList.slice(0, 20),
    elapsed: Date.now() - started,
    cached: cached || 0
  };
}

/**
 * 分组完成后在后台补全页面信息。
 *
 * **刻意不 await**，这是"补全并入一键分组"能同时保住速度和准确率的关键：
 *  - 分组速度：补全发生在回执之后，用户感知不到任何延迟；
 *  - 准确率：本次分组只读缓存，所以绝不会比不补全更差；补全的内容按网址进缓存，
 *    下次分组自动用上，只会越来越好；
 *  - 失败也无所谓：只是少补几个页面，分组结果不受任何影响。
 */
let enriching = false;
function scheduleEnrich(windowId) {
  if (enriching) return;
  enriching = true;
  Promise.resolve().then(async () => {
    try {
      const settings = await getSettings();
      if (!settings.autoEnrich) return;
      const granted = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
      if (!granted) return;
      const wId = windowId === undefined ? CURRENT_WINDOW : windowId;
      const tabs = await collectTabs(wId);
      if (!tabs.length) return;
      await runDeepAnalyze(tabs.map((t) => t.id), {
        requirePermission: false, perTabMs: 1800, budgetMs: 15000
      });
    } catch (e) {
      console.warn('[TabTidy] 后台补全页面信息失败（不影响分组）', e);
    } finally {
      enriching = false;
    }
  });
}

async function metaCacheStats() {
  const { metaCache = {} } = await chrome.storage.local.get('metaCache');
  return { cached: Object.keys(metaCache).length };
}

async function clearMetaCache() {
  await chrome.storage.local.set({ metaCache: {} });
  return { ok: true };
}

// ------------------------------------------------------------ 预览 / 分组

/**
 * 把重名的组并成一个。
 *
 * 为什么必须做：用户自定规则产出的组用的是"用户当时填的组名"，而兜底组固定叫"其他"。
 * 两者可能重名，落地时会被当成同一个标签组，但界面却按两个组展示——用户看到的就是
 * "几个毫不相关的标签页被塞进了同一组"。这里先把重名的合并掉，界面和落地就一致了。
 */
export function mergeSameName(groups) {
  const out = [];
  const byName = new Map();
  for (const g of groups) {
    const name = (g.name || '未命名').trim();
    const hit = byName.get(name);
    if (!hit) {
      const copy = {
        ...g, name,
        tabIds: [...(g.tabIds || [])],
        tabs: [...(g.tabs || [])],
        mergedFrom: [g.source]
      };
      byName.set(name, copy);
      out.push(copy);
      continue;
    }
    const seen = new Set(hit.tabIds);
    for (const id of g.tabIds || []) {
      if (seen.has(id)) continue;
      hit.tabIds.push(id);
      seen.add(id);
    }
    const seenTabs = new Set(hit.tabs.map((t) => t.id));
    for (const t of g.tabs || []) {
      if (seenTabs.has(t.id)) continue;
      hit.tabs.push(t);
      seenTabs.add(t.id);
    }
    hit.mergedFrom.push(g.source);
    hit.confidence = Math.max(hit.confidence || 0, g.confidence || 0);
  }
  for (const g of out) {
    if (g.mergedFrom.length > 1) g.source = 'mixed';
  }
  return out;
}

async function previewGroups(strategyId, windowId, overrides = {}) {
  const settings = await getSettings();
  const opts = {
    minTabs: overrides.minTabsPerGroup ?? settings.minTabsPerGroup,
    semanticThreshold: overrides.semanticThreshold ?? settings.semanticThreshold,
    maxGroupSize: overrides.maxGroupSize ?? settings.maxGroupSize
  };
  const wId = windowId === undefined ? CURRENT_WINDOW : windowId;

  // 注意：这里**不**跑页面内容补全。
  // 补全在 ORGANIZE 回执之后才触发，否则注入脚本会阻塞整个分组流程。
  // 分组只消费 metaCache 里已有的内容（collectTabs 会按 URL 去查）。
  const tabList = await collectTabs(wId);
  const metaUsed = tabList.filter((t) => t.meta).length;

  // 用户规则优先（「让分组听你的」写进来的规则 + 手动拖动学到的习惯）
  let learned = [];
  let pool = tabList;
  if (settings.learning) {
    const learning = await getLearning();
    const r = applyLearned(pool, learning, { minTabs: opts.minTabs });
    learned = r.groups;
    pool = r.rest;
  }

  // 收尾统一走这里，两条策略分支都不会漏：
  //   1. 按用户拖拽记忆的顺序排（组名对不上的自然被跳过）
  //   2. 保证配色互不重复 —— 各阶段各自动取色，拼起来必然撞色
  const savedOrder = (await getGroupOrder()).names;
  const fin = (gs) => assignUniqueColors(applyGroupOrder(mergeSameName(gs), savedOrder));

  if (strategyId === 'hybrid') {
    const r = groupHybrid(pool, {
      minTabs: opts.minTabs,
      semanticThreshold: opts.semanticThreshold,
      maxGroupSize: opts.maxGroupSize
    });
    return {
      groups: fin([...learned, ...r.groups]),
      tabs: tabList,
      meta: { learnedGroups: learned.length, metaUsed }
    };
  }

  const groups = await runStrategy(strategyId, pool, opts);
  return {
    groups: fin([...learned, ...groups]),
    tabs: tabList,
    meta: { learnedGroups: learned.length, metaUsed }
  };
}

// ------------------------------------------------------------ 消息路由

const HANDLERS = {
  async PING() {
    return { ok: true, version: chrome.runtime.getManifest().version, organizing };
  },

  async GET_TABS({ windowId }) {
    return { tabs: await collectTabs(windowId === undefined ? CURRENT_WINDOW : windowId) };
  },

  async PREVIEW({ strategy, windowId, overrides }) {
    const { groups, tabs, meta } = await previewGroups(strategy, windowId, overrides || {});
    return { groups, tabs, meta };
  },

  /**
   * 预览 + 落地。整个流程套了锁和总超时，绝不会出现"按钮一直转圈"。
   */
  async ORGANIZE({ strategy, windowId, overrides }) {
    if (organizing) {
      throw new Error('上一次分组还没结束，请等 1 秒再点');
    }
    organizing = true;
    try {
      const settings = await getSettings();
      const { groups, tabs, meta } = await previewGroups(strategy, windowId, overrides || {});

      const result = await withTimeout(applyGroups(groups, {
        keepExisting: settings.keepExistingGroups,
        collapse: settings.collapseGroups,
        windowId,
        skipMisc: false
      }), 60000, '分组任务');

      // 页面内容补全并入一键分组：先回执，再在后台补全。
      // 不 await 是关键 —— 分组速度完全不受影响；补全结果按网址进缓存，下次分组自动用上。
      scheduleEnrich(windowId);

      return { ...result, groups, meta, tabs };
    } finally {
      organizing = false;
    }
  },

  async APPLY_GROUPS({ groups, windowId, overrides }) {
    if (organizing) throw new Error('上一次分组还没结束，请等 1 秒再点');
    organizing = true;
    try {
      const settings = await getSettings();
      return await withTimeout(applyGroups(groups, {
        keepExisting: overrides?.keepExisting ?? settings.keepExistingGroups,
        collapse: overrides?.collapse ?? settings.collapseGroups,
        windowId
      }), 60000, '分组任务');
    } finally {
      organizing = false;
    }
  },

  async UNGROUP_ALL({ windowId }) {
    markSelfActing();
    const useCurrent = windowId == null || windowId === CURRENT_WINDOW;
    const tabs = await chrome.tabs.query(useCurrent ? { currentWindow: true } : { windowId });
    const ids = tabs.filter((t) => t.groupId != null && t.groupId >= 0).map((t) => t.id);
    if (ids.length) await chrome.tabs.ungroup(ids);
    return { ungrouped: ids.length };
  },

  async GET_SETTINGS() { return { settings: await getSettings() }; },
  async SET_SETTINGS({ patch }) { return { settings: await saveSettings(patch) }; },
  async GET_LEARNING() { return { learning: await getLearning() }; },

  async CLEAR_LEARNING() {
    await clearLearning();
    return { ok: true };
  },

  /** 用户点「开启读取页面内容」时立刻补一次，不用等下一次分组 */
  async ENRICH_NOW({ tabIds }) {
    return runDeepAnalyze(tabIds, {
      requirePermission: true, perTabMs: 2000, budgetMs: 30000
    });
  },

  async META_STATS() {
    const stats = await metaCacheStats();
    const permGranted = await chrome.permissions
      .contains({ origins: ['http://*/*', 'https://*/*'] })
      .catch(() => false);
    return { cached: stats.cached, permGranted };
  },

  async CLEAR_META_CACHE() {
    return clearMetaCache();
  },

  // ---- 「让分组听你的」：标注的持久化 + 转成分组规则 ----
  // 这是标注能影响分组的**唯一**路径。

  async GET_TRUTH() {
    return { truth: await getTruthByUrl() };
  },

  async SAVE_TRUTH({ truth }) {
    const n = await saveTruthByUrl(truth || {});
    return { saved: n };
  },

  async CLEAR_TRUTH() {
    await clearTruthByUrl();
    return { ok: true };
  },

  /**
   * 把标注的组名变成 网站 → 组名 规则写进规则库。
   */
  async IMPORT_TRUTH({ entries, overwrite = true }) {
    const settings = await getSettings();
    // 习惯开关关着的话规则不会被 applyLearned 使用，这里自动打开并如实告知
    let learningWasOff = false;
    if (!settings.learning) {
      await saveSettings({ learning: true });
      learningWasOff = true;
    }
    const stat = await importTruthAsRules(entries || [], { overwrite });

    // 顺带算出"因为每组最少标签页数限制而暂时不会生效"的组
    const byGroup = new Map();
    for (const e of entries || []) {
      const g = String(e?.group || '').trim();
      if (!g) continue;
      byGroup.set(g, (byGroup.get(g) || 0) + 1);
    }
    const tooSmall = [...byGroup.entries()]
      .filter(([, n]) => n < settings.minTabsPerGroup)
      .map(([name, n]) => ({ name, tabs: n }));

    return {
      ...stat,
      learningWasOff,
      minTabsPerGroup: settings.minTabsPerGroup,
      tooSmall,
      applied: stat.added + stat.updated + stat.unchanged
    };
  },

  /**
   * 弹窗里双击组名直接改名。
   *
   * 做法：把这一组里**每个网站**都写成「→ 新名字」的规则。
   * 不能走 recordCorrection —— 它首次只写 count: 1，而 applyLearned 要求
   * count >= minCount（默认 2），一次改名根本不会生效。
   * 这里走 importTruthAsRules，它直接给 weight 5，并且 origin 记为 truth。
   */
  async RENAME_GROUP({ hosts, name, from }) {
    const next = String(name || '').trim();
    // ⚠️ 这里收的是**主机名**（weixin.qq.com），不是 rootDomain 归并后的 qq.com。
    // 用后者的话，给微信输入法改名会顺手把 QQ邮箱 也写进同一条规则。
    const list = [...new Set(
      (hosts || [])
        .map((d) => String(d || '').trim().toLowerCase())
        .filter(Boolean)
    )];

    if (!next) throw new Error('组名不能为空');
    if ([...next].length > 20) throw new Error('组名最多 20 个字');
    if (!isLearnableName(next)) {
      throw new Error('「' + next + '」是兜底名（其他 / 未分组 / 杂项…），换个具体点的');
    }
    if (!list.length) throw new Error('这个组里没有可以记住的网站');

    // 规则只有在「记住我的分组习惯」开着时才会被使用
    const settings = await getSettings();
    let learningWasOff = false;
    if (!settings.learning) {
      await saveSettings({ learning: true });
      learningWasOff = true;
    }

    const stat = await importTruthAsRules(
      list.map((host) => ({ domain: host, group: next })),
      { overwrite: true, weight: 5 }
    );
    if (!stat.added && !stat.updated && !stat.unchanged) {
      throw new Error((stat.rejected[0] && stat.rejected[0].why) || '没有写入任何规则');
    }

    // 顺序记忆是按组名记的，改名之后要把旧名字顶替掉，否则这条记忆就失效了
    const oldName = String(from || '').trim();
    if (oldName && oldName !== next) {
      const ord = await getGroupOrder();
      const idx = ord.names.indexOf(oldName);
      if (idx >= 0) {
        const names = [...ord.names];
        names[idx] = next;
        await saveGroupOrder(names);
      }
    }

    return { name: next, domains: list.length, stat, learningWasOff };
  },

  /** 删掉指定的几条规则（设置页规则表里每条右侧的「删除」） */
  async DELETE_RULES({ keys }) {
    const removed = await deleteRules(keys);
    return { removed };
  },

  /** 保存用户在弹窗里拖出来的分组顺序，并立刻把标签栏里的原生组也排成这个顺序 */
  async SET_GROUP_ORDER({ names, windowId }) {
    const saved = await saveGroupOrder(names);
    // 只存不排的话，弹窗里显示是第一项、左边标签栏却还是老样子 —— 这是两套数据源
    const r = await applyNativeGroupOrder(windowId, saved.names).catch(() => ({ moved: 0 }));
    return { count: saved.names.length, updatedAt: saved.updatedAt, moved: r.moved || 0 };
  },

  // ---------------------------------------------------------------- 跨设备同步

  async SYNC_STATUS() {
    return await syncStatus();
  },

  /** 手动同步一次（设置页的「立即同步」）。平时是自动的。 */
  async SYNC_NOW() {
    const r = await runSync(true);
    return r || { ok: true, reason: 'busy' };
  }
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handler = HANDLERS[msg?.type];
  if (!handler) return false;
  Promise.resolve(handler(msg.payload || {}))
    .then((data) => sendResponse({ ok: true, data }))
    .catch((err) => {
      console.error('[TabTidy]', msg.type, err);
      sendResponse({ ok: false, error: String(err?.message || err) });
    });
  return true;
});

// ------------------------------------------------------------ 学习：监听用户的手动操作
//
// 两条判据缺一不可：
//  - isSelfActing()：快路径。我们正在批量操作时直接跳过，避免自己触发自己。
//  - wasMovedByUs() / wasTitledByUs()：慢路径，但**跨 Service Worker 重启有效**。
//    这是关键——SW 空闲 30 秒就被回收，模块里的时间戳变量会清零，
//    迟到的事件在新 SW 里就认不出来了，会把我们自己的自动分组误学成用户偏好。

function isPlainWebUrl(url) {
  return !!url && !/^(chrome|edge|about|devtools|view-source):/.test(url);
}

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.groupId === undefined) return;
  try {
    const settings = await getSettings();
    if (!settings.learning) return;
    if (!isPlainWebUrl(tab.url)) return;
    if (tab.groupId == null || tab.groupId < 0) return;

    if (isSelfActing()) return;

    const domain = rootDomain(tab.url);
    const host = hostOf(tab.url);

    // 这次移动是不是我们自己刚做的？是就什么都不记。
    if (await wasMovedByUs(tabId, tab.groupId)) return;

    const g = await chrome.tabGroups.get(tab.groupId);
    if (!g || !g.title) return;
    // 组名等于域名 → 是我们按域名自动分出来的，不是用户给这组起的名字
    if (isDomainLikeTitle(g.title, domain)) return;

    // 记精确主机名：拖 mail.qq.com 学到的规则不该波及 weixin.qq.com
    recordCorrection(host, g.title);
  } catch (e) { /* 标签页或分组已消失，忽略 */ }
});

chrome.tabGroups.onUpdated.addListener(async (group) => {
  if (!group || group.id == null) return;
  try {
    const settings = await getSettings();
    if (!settings.learning) return;
    if (!isLearnableName(group.title)) return;

    // 折叠、展开、改颜色都会触发这个事件，但它们都没改标题。
    // 只有标题真的变了才值得当学习样本。
    const known = await getKnownTitle(group.id);
    if (known === group.title) return;

    if (isSelfActing()) {
      await setKnownTitle(group.id, group.title);
      return;
    }
    // 标题是不是我们自己设的？
    if (await wasTitledByUs(group.id, group.title)) {
      await setKnownTitle(group.id, group.title);
      return;
    }

    await setKnownTitle(group.id, group.title);

    const tabs = await chrome.tabs.query({ groupId: group.id });
    for (const t of tabs) {
      if (!isPlainWebUrl(t.url)) continue;
      const domain = rootDomain(t.url);
      if (isDomainLikeTitle(group.title, domain)) continue;
      recordCorrection(hostOf(t.url), group.title);
    }
  } catch (e) { /* 忽略 */ }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  forgetTab(tabId).catch(() => {});
});
