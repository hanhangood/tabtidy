import { DEFAULT_SETTINGS } from '../lib/storage.js';

const $ = (id) => document.getElementById(id);

/** 和弹窗一样：必须带超时，否则后台不回执就会永久挂起 */
function send(type, payload, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error('后台无响应（超过 ' + Math.round(timeoutMs / 1000) + ' 秒）。请到 edge://extensions 重新加载本扩展'));
    }, timeoutMs);
    const finish = (fn) => (arg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(arg);
    };
    try {
      chrome.runtime.sendMessage({ type, payload }, finish((res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!res) return reject(new Error('后台无响应'));
        if (!res.ok) return reject(new Error(res.error));
        resolve(res.data);
      }));
    } catch (e) {
      finish(reject)(e);
    }
  });
}

function toast(msg, ms = 2000) {
  const host = $('toastHost');
  $('toast').textContent = msg;
  host.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { host.hidden = true; }, ms);
}

/** 套件的滑块用 --p（0–100）画已填充部分，需要我们自己同步 */
function syncSliderProgress() {
  const el = $('semanticThreshold');
  const min = Number(el.min), max = Number(el.max), v = Number(el.value);
  const p = max > min ? ((v - min) / (max - min)) * 100 : 0;
  el.style.setProperty('--p', String(Math.round(p * 100) / 100));
}

function fillForm(s) {
  $('collapseGroups').checked = s.collapseGroups;
  $('keepExistingGroups').checked = s.keepExistingGroups;

  $('minTabsPerGroup').value = s.minTabsPerGroup;
  $('maxGroupSize').value = s.maxGroupSize;
  $('semanticThreshold').value = s.semanticThreshold;
  $('semanticThresholdVal').textContent = Number(s.semanticThreshold).toFixed(2);
  syncSliderProgress();
  $('syncEnabled').checked = s.syncEnabled !== false;
}

function collectForm() {
  return {
    collapseGroups: $('collapseGroups').checked,
    keepExistingGroups: $('keepExistingGroups').checked,
    minTabsPerGroup: Number($('minTabsPerGroup').value) || 2,
    maxGroupSize: Number($('maxGroupSize').value) || 12,
    semanticThreshold: Number($('semanticThreshold').value),
    syncEnabled: $('syncEnabled').checked
  };
}

// ---------------------------------------------------------------- 置顶分组
//
// 整个"顺序"功能就只剩这一件事：记住用户拖到最上面的那个组。
// 这里只负责显示它、以及提供一个取消置顶的入口。

async function loadPinStat() {
  const el = $('pinStat');
  if (!el) return;
  try {
    const info = await send('PIN_INFO', {}, 8000);
    const bits = [];
    bits.push(info.pinned ? '置顶：' + info.pinned : '还没有置顶任何分组（把某个组拖到最上面即可）');
    if (!info.supported) bits.push('⚠️ 这个浏览器不能程序化调整分组位置');
    if (info.diag && info.diag.moved) bits.push('上次已搬到第一位');
    if (info.diag && info.diag.error && info.pinned) bits.push('上次：' + info.diag.error);
    el.textContent = bits.join(' · ');
  } catch (e) {
    el.textContent = '取不到置顶信息（' + e.message + '）';
  }
}

async function clearPin() {
  const btn = $('btnUnpin');
  btn.disabled = true;
  try {
    await send('CLEAR_PIN', {}, 10000);
    toast('已取消置顶');
    await loadPinStat();
  } catch (e) {
    toast('取消失败：' + e.message);
  } finally {
    btn.disabled = false;
  }
}

// ---------------------------------------------------------------- 跨设备同步
//
// 平时是自动的（后台在数据变化 / 云端变化 / 浏览器启动时各同步一次）。
// 这里只负责显示状态，加一个「同步」按钮用来立刻催一次。

async function loadSyncStat() {
  const el = $('syncStat');
  if (!el) return;
  try {
    const st = await send('SYNC_STATUS', {}, 8000);
    if (!st.available) {
      el.textContent = '这个浏览器不支持扩展云同步';
      return;
    }
    if (st.lastResult && st.lastResult.startsWith('error:')) {
      el.textContent = '⚠️ ' + st.lastResult.slice(6);
      return;
    }
    if (!st.enabled) {
      el.textContent = '已关闭自动同步';
      return;
    }
    const bits = [];
    if (st.lastSyncAt) {
      const d = new Date(st.lastSyncAt);
      bits.push('上次同步 ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'));
    } else {
      bits.push('还没同步过');
    }
    bits.push('这台 ' + st.localRules + ' 条规则');
    if (st.meta) bits.push('云端 ' + (st.meta.rules || 0) + ' 条');
    bits.push('配额 ' + Math.round(st.used / 1024) + ' / ' + Math.round(st.quota / 1024) + ' KB');
    el.textContent = bits.join(' · ');
  } catch (e) {
    el.textContent = '同步状态取不到（' + e.message + '）';
  }
}

async function syncNow() {
  const btn = $('btnSyncNow');
  btn.disabled = true;
  try {
    const r = await send('SYNC_NOW', {}, 25000);
    if (!r.ok) throw new Error(r.error || r.reason || '同步失败');

    if (r.reason === 'unchanged') toast('已经是最新的');
    else if (r.reason === 'both') toast('双向合并完成：' + r.rules + ' 条规则');
    else if (r.pushed) toast('已上传 ' + r.rules + ' 条规则');
    else if (r.pulled) toast('已从云端取回 ' + r.rules + ' 条规则');
    else toast('同步完成');

    if (r.pulled) {
      // 云端覆盖了本地，表单和规则表要跟着刷新
      const res = await send('GET_SETTINGS', {});
      fillForm(res.settings);
    }
    await loadSyncStat();
  } catch (e) {
    toast('同步失败：' + e.message);
  } finally {
    btn.disabled = false;
  }
}

// ---------------------------------------------------------------- 自动保存
//
// 以前三个勾选框只读不写：勾完必须再点一次「保存设置」，不点就白勾了。
// 对不熟悉技术的用户来说这是个标准的坑，所以改成**改动即保存**。
//
// ⚠️ 最关键的一条：必须在 boot() 成功之后才允许写。
//    否则页面刚打开、表单还是 HTML 默认值时用户随手点一下，
//    就把存储里的真实设置覆盖成默认值了 —— 那才是真的丢数据。

let formReady = false;     // boot() 成功读到设置后才置 true
let autoSaveTimer = null;

function setSaveStat(text) {
  const el = $('saveStat');
  if (el) el.textContent = text || '';
}

async function flushSave() {
  autoSaveTimer = null;
  if (!formReady) {
    setSaveStat('设置还没载入完成，这次改动没有保存');
    return;
  }
  try {
    await send('SET_SETTINGS', { patch: collectForm() });
    setSaveStat('已自动保存 ' + new Date().toLocaleTimeString('zh-CN'));
  } catch (e) {
    setSaveStat('保存失败：' + e.message);
    toast('保存失败：' + e.message);
  }
}

/** 输入框和滑块连续改动时不要每一下都写一次存储 */
function scheduleAutoSave() {
  if (autoSaveTimer) clearTimeout(autoSaveTimer);
  setSaveStat('正在保存…');
  autoSaveTimer = setTimeout(flushSave, 350);
}

async function reset() {
  if (!confirm('恢复为默认设置？分组规则不会被清除。')) return;
  const res = await send('SET_SETTINGS', { patch: structuredClone(DEFAULT_SETTINGS) });
  fillForm(res.settings);
  setSaveStat('已恢复默认');
  toast('已恢复默认');
}



// ---------------------------------------------------------------- 启动

/**
 * 顶层错误必须暴露到界面上。
 * 脚本一挂就静默留一张空表单，是最坏的表现形式——用户会以为"我的设置被清空了"，
 * 而实际上数据好好的。（v1.5.0 就踩过这个坑：一个未定义的函数调用让整页静默失效。）
 */
function showFatal(err) {
  console.error('[TabTidy 设置页]', err);
  let bar = document.getElementById('fatalBar');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'fatalBar';
    bar.className = 'fatal-bar';
    (document.querySelector('.page') || document.body).prepend(bar);
  }
  bar.textContent = '设置页脚本出错：' + (err && err.message ? err.message : String(err))
    + '。你的设置数据没有被改动。请到 edge://extensions 重新加载本扩展。';
}

function bindUI() {
  // ---- 所有普通控件：改动即保存 ----
  for (const id of ['collapseGroups', 'keepExistingGroups', 'minTabsPerGroup', 'maxGroupSize']) {
    $(id).addEventListener('change', scheduleAutoSave);
  }
  $('semanticThreshold').addEventListener('input', (e) => {
    $('semanticThresholdVal').textContent = Number(e.target.value).toFixed(2);
    syncSliderProgress();
    scheduleAutoSave();
  });
  $('semanticThreshold').addEventListener('change', scheduleAutoSave);

  $('btnReset').addEventListener('click', reset);
  $('btnUnpin').addEventListener('click', clearPin);
  $('btnSyncNow').addEventListener('click', syncNow);
  // 开关本身走统一的自动保存；后台监听到改动会自动同步一次
  $('syncEnabled').addEventListener('change', scheduleAutoSave);
}

/**
 * 把用户真实的设置填进表单，然后才允许写入。
 * formReady 这个闸门很重要：读成功之前不允许保存，免得用空表单覆盖真实设置。
 */
async function boot() {
  const res = await send('GET_SETTINGS', {});
  fillForm(res.settings);
  formReady = true;
  setSaveStat('改动会自动保存');
  await loadPinStat();
  await loadSyncStat();
}

// 兜底：任何未捕获的错误都显示出来，不要静默失败
window.addEventListener('error', (e) => showFatal(e.error || e.message));
window.addEventListener('unhandledrejection', (e) => showFatal(e.reason));

// 绑事件和取设置各自独立兜错：一边挂了不能拖累另一边
try {
  bindUI();
} catch (e) {
  showFatal(e);
}
boot().catch(showFatal);
