// Service Worker：消息路由 + 分组落地 + 分组规则

import { collectTabs, runStrategy, groupHybrid, assignUniqueColors, applyRenames } from './lib/grouping.js';
import {
  getSettings, saveSettings,
  getPinnedGroup, savePinnedGroup, clearPinnedGroup,
  getRenames, saveRename
} from './lib/storage.js';
import { hostOf } from './lib/text.js';
import { pinToFront, planPinMove } from './lib/move.js';
import { syncStatus, syncRun } from './lib/sync.js';

// ---------------------------------------------------------------- 自动同步
//
// 触发点有三个，都走 hash 去重，所以随便触发也不会产生无谓写入：
//   1. 本机数据变了（settings / renames / pinnedGroup 任一被写）
//   2. 云端被别的设备改了（sync 区 tt1_meta 变化）
//   3. SW 被唤醒 / 浏览器启动
//
// 注意 `_syncTimer` / `_syncRunning` 是模块级变量，SW 回收后会清零 ——
// 这没关系：它们只是防抖和重入保护，丢了对正确性没有影响。

const SYNC_DEBOUNCE = 800;

let _syncTimer = null;
let _syncRunning = false;

function scheduleSync(delay = SYNC_DEBOUNCE) {
  if (_syncTimer) clearTimeout(_syncTimer);
  _syncTimer = setTimeout(() => {
    _syncTimer = null;
    runSync().catch((e) => console.warn('[TabTidy] 自动同步失败', e));
  }, delay);
}

async function runSync(force = false) {
  if (_syncRunning) return null;
  _syncRunning = true;
  try {
    return await syncRun({ force });
  } finally {
    _syncRunning = false;
  }
}

try {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      // 本机数据变了 → 往外推
      if (changes.settings || changes.renames || changes.pinnedGroup) {
        scheduleSync();
      }
      return;
    }
    if (areaName === 'sync' && changes.tt1_meta) {
      // 云端变了 → 拉回来合并。自己写的也会触发一次，
      // 但下次 syncRun 会发现本地和云端内容一致，直接返回，不会写任何东西。
      scheduleSync();
    }
  });
} catch (e) { /* 非扩展环境忽略 */ }

try {
  chrome.runtime.onStartup.addListener(() => scheduleSync(0));
  chrome.runtime.onInstalled.addListener(() => scheduleSync(0));
} catch (e) { /* 忽略 */ }

// ---------------------------------------------------------------- 顺序记忆：原生标签栏拖动
//
// 用户除了在弹窗里拖，也可能直接在浏览器的标签栏里把某个分组拖到最前面。
// 那种拖动不会经过我们的界面，所以要监听 tabGroups.onMoved 再记一遍。
//
// 难点：chrome.tabGroups 的 Group 对象**没有 index 字段**（只有 Tab 有）。
// 好在同一组的标签页在标签栏里是连续的，所以「组的位置 = 组内标签页的最小 index」。
//
// 我们自己分组时会新建组、也会挪标签页，这些不该被当成"用户调整了顺序"，
// 所以 organizing 期间直接跳过。

// 我们自己搬动时，不要把它当成"用户手动调整了顺序"
let reorderingNative = false;
let lastNativeReorderAt = 0;

/** 上一次"搬置顶组"的结果，设置页拿它显示一行状态 */
let lastPinDiag = null;

/**
 * 原生标签栏里，用户把某个分组拖到了最前面 → 记成置顶。
 *
 * 只关心"是不是第一位"：位置的先后不管，所以这里不需要保存整张顺序表。
 */
async function maybePinFromNative(windowId) {
  const [groups, tabs] = await Promise.all([
    chrome.tabGroups.query({ windowId }),
    chrome.tabs.query({ windowId })
  ]);
  if (!groups || groups.length < 2) return;

  const titleOf = new Map(groups.map((g) => [g.id, String(g.title || '').trim()]));
  const first = new Map();
  const hosts = new Map();
  for (const t of tabs || []) {
    if (t.groupId == null || t.groupId < 0) continue;
    const cur = first.get(t.groupId);
    if (cur === undefined || t.index < cur) first.set(t.groupId, t.index);
    if (!hosts.has(t.groupId)) hosts.set(t.groupId, new Set());
    const h = hostOf(t.url || '');
    if (h) hosts.get(t.groupId).add(h);
  }
  if (first.size < 2) return;

  const topId = [...first.entries()].sort((a, b) => a[1] - b[1])[0][0];
  const name = titleOf.get(topId) || '';
  if (!name) return;
  await savePinnedGroup({ name, hosts: [...(hosts.get(topId) || [])] });
}

try {
  if (chrome.tabGroups && chrome.tabGroups.onMoved) {
    chrome.tabGroups.onMoved.addListener((group) => {
      if (organizing || reorderingNative) return;          // 我们自己搬的
      if (Date.now() - lastNativeReorderAt < 1500) return;  // 事件比 promise 晚到，挡掉回声
      maybePinFromNative(group.windowId)
        .catch((e) => console.warn('[TabTidy] 记录置顶分组失败', e));
    });
  }
} catch (e) { /* 老版本浏览器没有 onMoved，忽略即可 */ }

/**
 * 把置顶的那个分组搬到标签栏最前面 —— 只搬这一个，其余不碰。
 *
 * 为什么需要单独做：`applyGroups` 是幂等的（标签页已在正确的组里就什么都不做），
 * 它只决定新建组的先后，不会把已有组移到前面。
 *
 * 结果记在 lastPinDiag，设置页显示成一行，避免又出现"没生效但不知道原因"。
 */
async function applyPin(windowId) {
  const pin = await getPinnedGroup();
  const diag = { at: Date.now(), pinned: pin.name, ok: false, error: '', moved: 0 };
  lastPinDiag = diag;

  if (!pin.name) { diag.error = '还没置顶任何分组'; return diag; }
  if (!chrome.tabGroups || typeof chrome.tabGroups.move !== 'function') {
    diag.error = '这个浏览器没有 tabGroups.move，改不了分组位置';
    return diag;
  }

  let wId = windowId;
  if (wId == null || wId === CURRENT_WINDOW) {
    try {
      const win = await chrome.windows.getLastFocused({ populate: false });
      wId = win && win.id;
    } catch (e) { wId = null; }
  }
  if (wId == null) { diag.error = '拿不到窗口 id'; return diag; }

  let groups = [];
  let tabs = [];
  try {
    [groups, tabs] = await Promise.all([
      chrome.tabGroups.query({ windowId: wId }),
      chrome.tabs.query({ windowId: wId })
    ]);
  } catch (e) {
    diag.error = '读取分组失败：' + (e.message || e);
    return diag;
  }

  const step = planPinMove(groups, tabs || [], pin);
  if (!step) {
    // 要么置顶的组这次不存在，要么它已经在最前面 —— 都不用动
    diag.ok = true;
    return diag;
  }

  lastNativeReorderAt = Date.now();
  reorderingNative = true;
  try {
    await withTimeout(chrome.tabGroups.move(step.id, { index: step.index }), 5000, '置顶分组');
    diag.moved = 1;
    diag.ok = true;
  } catch (e) {
    diag.error = '搬动失败：' + (e.message || e);
  } finally {
    reorderingNative = false;
    lastNativeReorderAt = Date.now();
  }
  return diag;
}

const CURRENT_WINDOW = chrome.windows.WINDOW_ID_CURRENT;
const TAB_GROUP_NONE = -1;

// 同一时刻只允许一个分组任务在跑
let organizing = false;

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') chrome.runtime.openOptionsPage();
  cleanupPageContent().catch(() => {});
});

/**
 * 清掉旧版本「读取页面内容」留下的东西。
 *
 * v2.1.0 把这个功能整个删了，但老机器上还留着两样：
 *   1. `metaCache` 里抓过的页面正文（几百条，占存储）
 *   2. 用户当初授予的 `http://*` `https://*` 全站权限
 * 功能都没了还留着权限，属于隐形的越权，所以顺手撤掉。
 */
async function cleanupPageContent() {
  try {
    const { metaCache } = await chrome.storage.local.get('metaCache');
    if (metaCache) await chrome.storage.local.remove('metaCache');
  } catch (e) { /* 忽略 */ }
  try {
    await chrome.permissions.remove({ origins: ['http://*/*', 'https://*/*'] });
  } catch (e) { /* 没授权过就会抛，忽略 */ }
}

// ------------------------------------------------------------ 工具

/** 给任何 Promise 加超时。Chrome 的 tabGroups / tabs API 偶发不回调，没有这个就会永久卡住。 */
function withTimeout(promise, ms, label) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(label + ' 超时（' + ms + 'ms）')), ms);
    Promise.resolve(promise).then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); }
    );
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ------------------------------------------------------------ 落地分组

/**
 * 把分组结果应用到浏览器原生标签组。
 *
 * 关键设计：**幂等**。
 * 第一次分组后标签页已经在组里了，第二次再点不应该把标签页搬来搬去
 * （搬动会让弹窗失焦关闭，也容易和 tabGroups.update 抢状态导致卡死）。
 * 所以这里先做快照，凡是"已经待在正确组里"的直接跳过，不对它调任何写 API。
 *
 * @returns {{applied: Array, alreadyOk: Array, failed: Array}}
 */
export async function applyGroups(groups, opts = {}) {
  const { keepExisting = true, collapse = false, windowId, skipMisc = false } = opts;
  // 归一化：-2 (WINDOW_ID_CURRENT) 和 undefined 都当作"当前窗口"，不能直接塞进 windowId 过滤器
  const wId = (windowId == null || windowId === CURRENT_WINDOW) ? null : windowId;

  const existing = await chrome.tabGroups.query(wId != null ? { windowId: wId } : {});
  const byTitle = new Map();
  for (const tg of existing) {
    if (tg.title) byTitle.set(tg.title, tg);
  }

  if (!keepExisting) {
    const autoTitles = new Set(groups.map((g) => g.name));
    for (const tg of existing) {
      if (!autoTitles.has(tg.title)) continue;
      const tabs = await chrome.tabs.query({ groupId: tg.id });
      if (tabs.length) await chrome.tabs.ungroup(tabs.map((t) => t.id));
      byTitle.delete(tg.title);
    }
  }

  const applied = [];
  const alreadyOk = [];
  const failed = [];
  for (const g of groups) {
    if (skipMisc && g.source === 'misc') continue;
    const title = (g.name || '未命名').slice(0, 32);
    const wantColor = g.color || 'grey';
    const wantCollapsed = !!collapse;

    const live = [];
    const currentGroups = new Set();
    for (const id of g.tabIds || []) {
      try {
        const t = await chrome.tabs.get(id);
        live.push(id);
        currentGroups.add(t.groupId == null ? TAB_GROUP_NONE : t.groupId);
      } catch (e) { /* 标签页已关闭 */ }
    }
    if (!live.length) continue;

    const reuse = byTitle.get(title);

    // 幂等快路径：这批标签页全部已经待在目标组里 → 一个写 API 都不调，直接跳过。
    // 这是"第二次点击智能分组"能瞬间完成、且不再卡住的原因。
    if (reuse && live.length === (g.tabIds || []).length
        && currentGroups.size === 1 && currentGroups.has(reuse.id)) {
      const sameLook = reuse.color === wantColor && reuse.collapsed === wantCollapsed;
      if (sameLook) {
        alreadyOk.push({ name: title, groupId: reuse.id, count: live.length });
        continue;
      }
      try {
        await withTimeout(chrome.tabGroups.update(reuse.id, {
          title, color: wantColor, collapsed: wantCollapsed
        }), 8000, '更新组「' + title + '」外观');
        alreadyOk.push({ name: title, groupId: reuse.id, count: live.length });
      } catch (e) {
        failed.push({ name: title, error: String(e.message || e) });
      }
      continue;
    }

    let groupId;
    try {
      if (reuse) {
        groupId = await withTimeout(
          chrome.tabs.group({ tabIds: live, groupId: reuse.id }),
          8000, '把标签页移入「' + title + '」'
        );
      } else {
        groupId = await withTimeout(
          chrome.tabs.group({
            tabIds: live,
            ...(wId != null ? { createProperties: { windowId: wId } } : {})
          }),
          8000, '新建标签组「' + title + '」'
        );
      }
    } catch (e) {
      console.warn('[TabTidy] 建组失败', title, e);
      failed.push({ name: title, error: String(e.message || e) });
      continue;
    }

    // 组可能因为成员被搬空而被浏览器自动删掉，所以更新属性单独兜一层错误
    try {
      await withTimeout(chrome.tabGroups.update(groupId, {
        title, color: wantColor, collapsed: wantCollapsed
      }), 8000, '设置「' + title + '」的标题与颜色');
      const fresh = await chrome.tabGroups.get(groupId).catch(() => null);
      if (fresh) byTitle.set(title, fresh);
    } catch (e) {
      console.warn('[TabTidy] 更新组属性失败', title, e);
      failed.push({ name: title, error: '设置属性失败：' + String(e.message || e) });
    }

    applied.push({ name: title, groupId, count: live.length });

    // 让出主线程，避免一次性几百个 chrome API 调用把消息回执挤到超时之后
    await sleep(0);
  }

  // 分组完顺手把置顶的那一个搬到最前面（只搬它一个，其余不动）
  await applyPin(wId).catch(() => {});

  return { applied, alreadyOk, failed };
}

// ------------------------------------------------------------ 预览 / 分组

/**
 * 把重名的组并成一个。
 *
 * 为什么必须做：用户自定规则产出的组用的是"用户当时填的组名"，而兜底组固定叫"其他"。
 * 两者可能重名，落地时会被当成同一个标签组，但界面却按两个组展示——用户看到的就是
 * "几个毫不相关的标签页被塞进了同一组"。这里先把重名的合并掉，界面和落地就一致了。
 */
export function mergeSameName(groups) {
  const out = [];
  const byName = new Map();
  for (const g of groups) {
    const name = (g.name || '未命名').trim();
    const hit = byName.get(name);
    if (!hit) {
      const copy = {
        ...g, name,
        tabIds: [...(g.tabIds || [])],
        tabs: [...(g.tabs || [])],
        mergedFrom: [g.source]
      };
      byName.set(name, copy);
      out.push(copy);
      continue;
    }
    const seen = new Set(hit.tabIds);
    for (const id of g.tabIds || []) {
      if (seen.has(id)) continue;
      hit.tabIds.push(id);
      seen.add(id);
    }
    const seenTabs = new Set(hit.tabs.map((t) => t.id));
    for (const t of g.tabs || []) {
      if (seenTabs.has(t.id)) continue;
      hit.tabs.push(t);
      seenTabs.add(t.id);
    }
    hit.mergedFrom.push(g.source);
    hit.confidence = Math.max(hit.confidence || 0, g.confidence || 0);
  }
  for (const g of out) {
    if (g.mergedFrom.length > 1) g.source = 'mixed';
  }
  return out;
}

async function previewGroups(strategyId, windowId, overrides = {}) {
  const settings = await getSettings();
  const opts = {
    minTabs: overrides.minTabsPerGroup ?? settings.minTabsPerGroup,
    semanticThreshold: overrides.semanticThreshold ?? settings.semanticThreshold,
    maxGroupSize: overrides.maxGroupSize ?? settings.maxGroupSize
  };
  const wId = windowId === undefined ? CURRENT_WINDOW : windowId;

  // 只读标签页的标题和网址（chrome.tabs 免费提供），不注入任何脚本。
  const tabList = await collectTabs(wId);

  // 分组**全部由算法决定**（v2.0.0 起不再有"学到的规则"）。
  // 收尾按顺序做三件事：
  //   1. 套上你亲手改过的名字（唯一不属于算法的输入，见 applyRenames）
  //   2. 把置顶的那个分组挪到第一位（其余顺序不管）
  //   3. 保证配色互不重复 —— 各阶段各自动取色，拼起来必然撞色
  const pin = await getPinnedGroup();
  const ren = await getRenames();
  const fin = (gs) => assignUniqueColors(
    pinToFront(applyRenames(mergeSameName(gs), ren.map), pin)
  );

  if (strategyId === 'hybrid') {
    const r = groupHybrid(tabList, {
      minTabs: opts.minTabs,
      semanticThreshold: opts.semanticThreshold,
      maxGroupSize: opts.maxGroupSize
    });
    return { groups: fin(r.groups), tabs: tabList };
  }

  const groups = await runStrategy(strategyId, tabList, opts);
  return { groups: fin(groups), tabs: tabList };
}

// ------------------------------------------------------------ 消息路由

const HANDLERS = {
  async PING() {
    return { ok: true, version: chrome.runtime.getManifest().version, organizing };
  },

  async GET_TABS({ windowId }) {
    return { tabs: await collectTabs(windowId === undefined ? CURRENT_WINDOW : windowId) };
  },

  async PREVIEW({ strategy, windowId, overrides }) {
    const { groups, tabs } = await previewGroups(strategy, windowId, overrides || {});
    return { groups, tabs };
  },

  /**
   * 预览 + 落地。整个流程套了锁和总超时，绝不会出现"按钮一直转圈"。
   */
  async ORGANIZE({ strategy, windowId, overrides }) {
    if (organizing) {
      throw new Error('上一次分组还没结束，请等 1 秒再点');
    }
    organizing = true;
    try {
      const settings = await getSettings();
      const { groups, tabs } = await previewGroups(strategy, windowId, overrides || {});

      const result = await withTimeout(applyGroups(groups, {
        keepExisting: settings.keepExistingGroups,
        collapse: settings.collapseGroups,
        windowId,
        skipMisc: false
      }), 60000, '分组任务');

      return { ...result, groups, tabs };
    } finally {
      organizing = false;
    }
  },

  async APPLY_GROUPS({ groups, windowId, overrides }) {
    if (organizing) throw new Error('上一次分组还没结束，请等 1 秒再点');
    organizing = true;
    try {
      const settings = await getSettings();
      return await withTimeout(applyGroups(groups, {
        keepExisting: overrides?.keepExisting ?? settings.keepExistingGroups,
        collapse: overrides?.collapse ?? settings.collapseGroups,
        windowId
      }), 60000, '分组任务');
    } finally {
      organizing = false;
    }
  },

  async UNGROUP_ALL({ windowId }) {
    const useCurrent = windowId == null || windowId === CURRENT_WINDOW;
    const tabs = await chrome.tabs.query(useCurrent ? { currentWindow: true } : { windowId });
    const ids = tabs.filter((t) => t.groupId != null && t.groupId >= 0).map((t) => t.id);
    if (ids.length) await chrome.tabs.ungroup(ids);
    return { ungrouped: ids.length };
  },

  /**
   * 改分组名。
   *
   * v2.0.0 起不再写"规则"（学习机制已移除），只做三件事：
   *   1. 把当前标签栏里叫这个名字的原生组改名
   *   2. 记一条「算法算出来叫 X → 你改成 Y」，下次分组自动套用
   *   3. 如果置顶的是它，跟着改（置顶是按组名记的）
   */
  async RENAME_GROUP({ from, name }) {
    const oldName = String(from || '').trim();
    const next = String(name || '').trim();
    if (!next) throw new Error('组名不能为空');
    if ([...next].length > 20) throw new Error('组名最多 20 个字');
    if (!oldName) throw new Error('不知道该改哪个组');

    let renamed = 0;
    if (next !== oldName) {
      // 只改标签栏里真实存在、且当前叫这个名字的组
      const all = await chrome.tabGroups.query({});
      for (const g of all) {
        if (String(g.title || '').trim() !== oldName) continue;
        try {
          await withTimeout(chrome.tabGroups.update(g.id, { title: next }), 8000, '改分组名');
          renamed++;
        } catch (e) {
          console.warn('[TabTidy] 改分组名失败', g.id, e);
        }
      }

      await saveRename(oldName, next);

      const pin = await getPinnedGroup();
      if (pin.name === oldName) await savePinnedGroup({ ...pin, name: next });
    }

    return { name: next, renamed };
  },

  async GET_SETTINGS() { return { settings: await getSettings() }; },
  async SET_SETTINGS({ patch }) { return { settings: await saveSettings(patch) }; },

  /** 当前置顶的分组 + 上一次搬动的结果（设置页显示一行状态用） */
  async PIN_INFO() {
    const pin = await getPinnedGroup();
    let native = [];
    try {
      const win = await chrome.windows.getLastFocused({ populate: false });
      const [gs, ts] = await Promise.all([
        chrome.tabGroups.query({ windowId: win.id }),
        chrome.tabs.query({ windowId: win.id })
      ]);
      const titleOf = new Map((gs || []).map((g) => [g.id, String(g.title || '').trim()]));
      const first = new Map();
      for (const t of ts || []) {
        if (t.groupId == null || t.groupId < 0) continue;
        const cur = first.get(t.groupId);
        if (cur === undefined || t.index < cur) first.set(t.groupId, t.index);
      }
      native = [...first.entries()]
        .sort((a, b) => a[1] - b[1])
        .map(([id]) => titleOf.get(id))
        .filter(Boolean);
    } catch (e) { /* 忽略 */ }

    return {
      pinned: pin.name,
      pinnedAt: pin.updatedAt,
      native,
      diag: lastPinDiag,
      supported: !!(chrome.tabGroups && typeof chrome.tabGroups.move === 'function')
    };
  },

  /** 用户把某个分组拖到了最上面：记成置顶，并把原生组搬上去 */
  async SET_PIN({ name, hosts, windowId }) {
    const saved = await savePinnedGroup({ name, hosts });
    const diag = await applyPin(windowId);
    return { pinned: saved.name, moved: diag.moved || 0, ok: !!diag.ok, error: diag.error || '' };
  },

  /** 取消置顶 */
  async CLEAR_PIN() {
    await clearPinnedGroup();
    return { pinned: '' };
  },

  /** 按当前置顶重新搬一次（设置页的「置顶一下」按钮） */
  async PIN_APPLY({ windowId }) {
    return await applyPin(windowId);
  },

  // ---------------------------------------------------------------- 跨设备同步

  async SYNC_STATUS() {
    return await syncStatus();
  },

  /** 手动同步一次（设置页的「立即同步」）。平时是自动的。 */
  async SYNC_NOW() {
    const r = await runSync(true);
    return r || { ok: true, reason: 'busy' };
  }
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handler = HANDLERS[msg?.type];
  if (!handler) return false;
  Promise.resolve(handler(msg.payload || {}))
    .then((data) => sendResponse({ ok: true, data }))
    .catch((err) => {
      console.error('[TabTidy]', msg.type, err);
      sendResponse({ ok: false, error: String(err?.message || err) });
    });
  return true;
});
