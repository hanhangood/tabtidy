// 弹窗：只有一个按钮。
// 没有任何策略选择、没有评分、没有 AI —— 分组方式固定为「智能分组」。

const $ = (id) => document.getElementById(id);

// 只有真正在扩展里跑时才走消息通道。直接在浏览器里打开本文件时走下面的示例数据，
// 方便查看视觉稿、也方便调试样式。
const IS_EXTENSION = location.protocol === 'chrome-extension:';

const DEMO_TABS = [
  { id: 1, title: 'ofa-order-system - Pull requests', url: 'https://github.com/u/ofa-order-system/pulls', domain: 'github.com' },
  { id: 2, title: 'Element Plus 表格组件 Table', url: 'https://element-plus.org/zh-CN/component/table.html', domain: 'element-plus.org' },
  { id: 3, title: 'Vue 3 组合式 API 文档', url: 'https://cn.vuejs.org/guide/extras/composition-api-faq.html', domain: 'vuejs.org' },
  { id: 4, title: '机械键盘 87键 - 京东', url: 'https://item.jd.com/100012043978.html', domain: 'jd.com' },
  { id: 5, title: '键帽 PBT 套装 - 淘宝', url: 'https://item.taobao.com/item.htm?id=123456', domain: 'taobao.com' },
  { id: 6, title: '今天天气怎么样', url: 'https://weather.example.com/today', domain: 'weather.example.com' }
];
const DEMO_GROUPS = [
  { key: 'd1', name: '订单系统', color: 'blue', source: 'domain', confidence: 0.9, tabIds: [1] },
  { key: 'd2', name: '前端项目', color: 'purple', source: 'domain', confidence: 0.9, tabIds: [2, 3] },
  { key: 'd3', name: '购物与电商', color: 'orange', source: 'topic', confidence: 0.85, tabIds: [4, 5] },
  { key: 'd4', name: '其他', color: 'grey', source: 'misc', confidence: 0.2, tabIds: [6] }
];

const STRATEGY = 'hybrid';
let settings = null;
let currentResult = null;

/**
 * 给消息加超时。没有这层保护，只要后台回执没回来，按钮就会永远转圈。
 */
function send(type, payload, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error('后台无响应（超过 ' + Math.round(timeoutMs / 1000) + ' 秒）。请再点一次，或到 edge://extensions 重新加载本扩展'));
    }, timeoutMs);

    const finish = (fn) => (arg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(arg);
    };

    try {
      chrome.runtime.sendMessage({ type, payload }, finish((res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!res) return reject(new Error('后台无响应'));
        if (!res.ok) return reject(new Error(res.error));
        resolve(res.data);
      }));
    } catch (e) {
      finish(reject)(e);
    }
  });
}

function toast(msg, ms = 1800) {
  const host = $('toastHost');
  $('toast').textContent = msg;
  host.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { host.hidden = true; }, ms);
}

function setStatus(text) {
  $('status').textContent = text || '';
}

// ---------------------------------------------------------------- 结果列表

// 只对需要解释的来源显示 Chip；域名/主题来源从组名就能看出来，不占地方。
// v2.0.0 起没有"你的规则"这一档了（学习机制已整块移除）。
const SOURCE_LABEL = { misc: '兜底' };
const SOURCE_HINT = {
  misc: '域名、主题都没能归类，或者不够成组的零散标签页。'
};
const SOURCE_VARIANT = { misc: 's-chip--grey' };

function svgUse(id, cls) {
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', cls);
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS(NS, 'use');
  use.setAttribute('href', id);
  svg.appendChild(use);
  return svg;
}

/** 一行的副标题：几个标签页、必要时说明跨了几个网站 */
function subtitleFor(g) {
  const n = g.tabIds.length;
  let s = n + ' 个标签页';
  if (g.source === 'misc') {
    const domains = new Set((g.tabs || []).map((t) => t.domain).filter(Boolean));
    if (domains.size > 1) s += ' · ' + domains.size + ' 个网站';
  }
  return s;
}

function sourceHintText(g) {
  let s = SOURCE_HINT[g.source] || '';
  if (g.source === 'misc') {
    const domains = new Set((g.tabs || []).map((t) => t.domain).filter(Boolean));
    if (domains.size > 1) s += `\n\n本组含 ${domains.size} 个不同网站：${[...domains].join('、')}`;
  }
  return s.trim();
}

/**
 * 双击组名 → 原地变成输入框，回车保存、Esc 取消、失焦也保存。
 *
 * 保存走 RENAME_GROUP：后台改原生组的标题，并记一条「算法名 → 你的名字」，
 * 所以下次分组仍然归到一起，并且用你起的名字。
 *
 * 注意：双击会先触发两次 click，让展开态翻转两次后回到原样 —— 这是刻意的，
 * 不加 `e.detail` 判断是因为那会让"双击改名"顺带把组展开/收起。
 */
function startRename(g, titleEl) {
  if (titleEl.parentElement && titleEl.parentElement.querySelector('.popup__rename')) return;

  const input = document.createElement('input');
  input.className = 's-textfield popup__rename';
  input.value = g.name;
  input.setAttribute('aria-label', '修改组名');
  input.spellcheck = false;

  let done = false;

  const finish = async (commit) => {
    if (done) return;
    done = true;

    const next = input.value.trim();
    if (input.isConnected) input.replaceWith(titleEl);

    if (!commit || !next || next === g.name) return;

    const before = g.name;
    titleEl.textContent = next;          // 先乐观更新，失败再回滚

    try {
      const res = await send('RENAME_GROUP', { from: before, name: next }, 10000);
      toast('已改名：' + res.name);
      await loadPreview();
    } catch (e) {
      titleEl.textContent = before;      // 回滚
      toast('改名失败：' + e.message);
    }
  };

  input.addEventListener('click', (e) => e.stopPropagation());
  input.addEventListener('mousedown', (e) => e.stopPropagation());
  input.addEventListener('dblclick', (e) => e.stopPropagation());
  input.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter') { e.preventDefault(); finish(true); }
    else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
  });
  // 刚插进去的一瞬间可能被别的东西抢走焦点（弹窗自身的聚焦、重绘等），
  // 那就立刻 finish → 输入框一闪而过，用户看到的就是"双击没反应"。所以抢回来一次。
  const openedAt = Date.now();
  let refocused = false;
  input.addEventListener('blur', () => {
    if (!refocused && Date.now() - openedAt < 150) {
      refocused = true;
      input.focus();
      return;
    }
    finish(true);
  });

  titleEl.replaceWith(input);
  input.focus();
  input.select();
}

// ---------------------------------------------------------------- 置顶分组
//
// **只支持一个操作：把某个分组拖到最上面 → 它成为"置顶"，下次分组/刷新后还在第一位。**
// 其余分组的先后不做任何要求，所以这里不记整张顺序表，只记一个名字。

let dragEl = null;      // 正在拖的行
let markEl = null;      // 当前显示插入线的行
let lastGroups = [];    // 上一次渲染的分组

function clearDropMark() {
  if (markEl) {
    markEl.classList.remove('drop-before', 'drop-after');
    markEl = null;
  }
}

async function pinGroup(name) {
  const g = lastGroups.find((x) => x.name === name);
  // 顺手记下这个组里的网站：组以后被改名了，还能靠它认出来
  const hosts = g
    ? [...new Set((g.tabs || []).map((t) => t.host || t.domain).filter(Boolean))]
    : [];

  let winId;
  try {
    const w = await chrome.windows.getCurrent();
    winId = w && w.id;
  } catch (e) { /* 交给后台兜底 */ }

  try {
    const r = await send('SET_PIN', { name, hosts, windowId: winId }, 15000);
    toast(r.ok ? '已置顶：' + name : '置顶没生效：' + (r.error || '原因未知'));
  } catch (e) {
    toast('置顶失败：' + e.message);
  }
  await loadPreview();
}

function bindDrag(wrap) {
  wrap.addEventListener('dragstart', (e) => {
    // 改名输入框里拖选文字时不应该触发整行拖动
    if (e.target && e.target.tagName === 'INPUT') { e.preventDefault(); return; }
    dragEl = wrap;
    wrap.classList.add('is-dragging');
    if (e.dataTransfer) {
      e.dataTransfer.effectAllowed = 'move';
      try { e.dataTransfer.setData('text/plain', wrap.dataset.groupName || ''); } catch (err) { /* 忽略 */ }
    }
  });

  wrap.addEventListener('dragend', () => {
    wrap.classList.remove('is-dragging');
    clearDropMark();
    dragEl = null;
  });

  wrap.addEventListener('dragover', (e) => {
    if (!dragEl || dragEl === wrap) return;
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
    const rect = wrap.getBoundingClientRect ? wrap.getBoundingClientRect() : null;
    const after = rect ? (e.clientY - rect.top) > rect.height / 2 : true;
    clearDropMark();
    wrap.classList.add(after ? 'drop-after' : 'drop-before');
    markEl = wrap;
  });

  wrap.addEventListener('dragleave', () => {
    if (markEl === wrap) clearDropMark();
  });

  wrap.addEventListener('drop', (e) => {
    e.preventDefault();
    if (!dragEl || dragEl === wrap) { clearDropMark(); return; }

    const after = wrap.classList.contains('drop-after');
    const to = Number(wrap.dataset.index);
    clearDropMark();
    if (!Number.isFinite(to)) return;

    // 只有"落在第一行之前"才是一个有意义的操作 —— 那是"拖到最上面"。
    // 拖到中间/底部不做任何事：其余分组的先后本来就没有要求。
    if (after || to !== 0) {
      toast('把想要的那个组拖到最上面就行');
      loadPreview().catch(() => {});
      return;
    }
    pinGroup(dragEl.dataset.groupName || '');
  });
}

function renderGroups(groups, tabs) {
  lastGroups = groups;          // 拖动排序要用当前这份顺序
  const box = $('results');
  const empty = $('empty');
  box.innerHTML = '';
  const tabMap = new Map(tabs.map((t) => [t.id, t]));

  if (!groups.length) {
    box.hidden = true;
    empty.hidden = false;
    return;
  }
  box.hidden = false;
  empty.hidden = true;

  for (const [gi, g] of groups.entries()) {
    const wrap = document.createElement('li');
    wrap.className = 'popup__row';
    wrap.draggable = true;
    wrap.dataset.index = String(gi);
    wrap.dataset.groupName = g.name;

    // ---- 分组行：色点 + 标题/副标题 + 来源 Chip + 展开箭头 ----
    // 刻意**不加** data-pressable：套件对它的按下规则是"整行变蓝 + 文字刷白"，
    // 而双击改名会触发两次 click → 蓝底闪两次。按下反馈交给 ui.css 里更轻的那档。
    const row = document.createElement('div');
    row.className = 's-list-item popup__group';

    const dot = document.createElement('span');
    dot.className = 'popup__dot popup__dot--' + (g.color || 'grey');
    row.appendChild(dot);

    const text = document.createElement('div');
    text.className = 's-list-item__text';
    const title = document.createElement('div');
    title.className = 's-list-item__title';
    title.textContent = g.name;
    title.title = '双击改名 · 按住拖到最上面可置顶';
    // 双击绑在**整块文字**（标题 + 副标题）上，不只是一行 16px 高的标题：
    // 不然稍微点低一点就落在副标题上，什么也不会发生。
    text.addEventListener('dblclick', (e) => {
      e.stopPropagation();
      startRename(g, title);
    });
    const sub = document.createElement('div');
    sub.className = 's-list-item__subtitle';
    sub.textContent = subtitleFor(g);
    text.append(title, sub);
    row.appendChild(text);

    const detail = document.createElement('div');
    detail.className = 's-list-item__detail';
    if (SOURCE_LABEL[g.source]) {
      const chip = document.createElement('span');
      chip.className = 's-chip popup__detail-chip ' + (SOURCE_VARIANT[g.source] || 's-chip--grey');
      chip.textContent = SOURCE_LABEL[g.source];
      chip.title = sourceHintText(g);
      detail.appendChild(chip);
    }
    // 双击是主入口，但双击依赖"两次点击落在同一个元素"，
    // 中间只要发生一次重绘/拖动就会失效。所以再给一个点了就一定生效的按钮。
    const renameBtn = document.createElement('button');
    renameBtn.type = 'button';
    renameBtn.className = 's-btn s-btn--text popup__rename-btn';
    renameBtn.textContent = '改名';
    renameBtn.title = '改这个名字';
    renameBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      startRename(g, title);
    });
    detail.appendChild(renameBtn);

    detail.appendChild(svgUse('#si-chevron-down', 's-icon s-icon--16'));
    row.appendChild(detail);

    // ---- 展开后的标签页行（套件的 List Tile 3 形态，自己做成嵌套行） ----
    const tabsBox = document.createElement('div');
    tabsBox.className = 'popup__tabs';
    tabsBox.hidden = true;

    for (const id of g.tabIds) {
      const t = tabMap.get(id);
      if (!t) continue;
      const tr = document.createElement('div');
      tr.className = 's-list-item popup__tab';

      const ttl = document.createElement('div');
      ttl.className = 's-list-item__title';
      ttl.textContent = t.title || t.url;
      ttl.title = t.url;

      const dm = document.createElement('div');
      dm.className = 's-list-item__subtitle';
      dm.textContent = t.domain;

      tr.append(ttl, dm);
      tr.addEventListener('click', async () => {
        try {
          await chrome.tabs.update(id, { active: true });
          const tab = await chrome.tabs.get(id);
          await chrome.windows.update(tab.windowId, { focused: true });
          window.close();
        } catch (e) { toast('标签页已关闭'); }
      });
      tabsBox.appendChild(tr);
    }

    row.addEventListener('click', () => {
      const open = row.classList.toggle('is-open');
      tabsBox.hidden = !open;
    });

    bindDrag(wrap);

    wrap.append(row, tabsBox);
    box.appendChild(wrap);
  }
}

// ---------------------------------------------------------------- 主操作

async function refreshCount() {
  try {
    const { tabs } = await send('GET_TABS', {});
    $('tabCount').textContent = tabs.length ? `${tabs.length} 个标签页` : '';
  } catch (e) {
    $('tabCount').textContent = '';
  }
}

async function loadPreview() {
  try {
    const res = await send('PREVIEW', { strategy: STRATEGY, overrides: {} });
    currentResult = { groups: res.groups, tabs: res.tabs };
    renderGroups(res.groups, res.tabs);
  } catch (e) {
    setStatus('预览失败：' + e.message);
  }
}

/** 唯一的主操作：分组 + 落地。 */
async function doOrganize() {
  const btn = $('btnOrganize');
  btn.disabled = true;
  setStatus('正在分组…');
  try {
    const res = await send('ORGANIZE', { strategy: STRATEGY, overrides: {} });
    const applied = res.applied || [];
    const alreadyOk = res.alreadyOk || [];
    const failed = res.failed || [];

    if (applied.length) {
      setStatus(`已建好 ${applied.length} 个分组，共 ${applied.reduce((s, a) => s + a.count, 0)} 个标签页`);
    } else if (alreadyOk.length) {
      setStatus('分组已是最新，无需改动');
    } else {
      setStatus('没有需要变更的分组');
    }
    if (failed.length) setStatus(`有 ${failed.length} 组没成功：` + failed.map((f) => f.name).join('、'));

    const list = (res.tabs && res.tabs.length) ? res.tabs : (currentResult?.tabs || []);
    currentResult = { groups: res.groups || [], tabs: list };
    renderGroups(res.groups || [], list);
  } catch (e) {
    setStatus('失败：' + e.message);
  } finally {
    btn.disabled = false;
  }
}

async function doUngroup() {
  try {
    const res = await send('UNGROUP_ALL', {});
    setStatus(`已取消 ${res.ungrouped} 个标签页的分组`);
    $('results').innerHTML = '';
    currentResult = null;
  } catch (e) {
    setStatus('失败：' + e.message);
  }
}

// ---------------------------------------------------------------- 一次性提示条

/**
 * 只在"开启自动补全 + 还没授权 + 还没问过"三条同时成立时出现，
 * 问过或拒过一次之后永久消失，不再打扰。
 */
async function maybeShowPrompt() {
  $('prompt').hidden = true;
  if (!settings || !settings.autoEnrich || settings.enrichPromptDone) return;
  let granted = false;
  try {
    granted = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
  } catch (e) { /* 查不了就当没授权 */ }
  if (granted) {
    send('SET_SETTINGS', { patch: { enrichGranted: true, enrichPromptDone: true } }).catch(() => {});
    return;
  }
  $('prompt').hidden = false;
}

async function dismissPrompt() {
  $('prompt').hidden = true;
  try {
    await send('SET_SETTINGS', { patch: { enrichPromptDone: true } });
    settings.enrichPromptDone = true;
  } catch (e) { /* 下次再说 */ }
}

async function enableEnrich() {
  try {
    // 权限申请必须由扩展页面在用户手势里发起
    const granted = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] });
    if (!granted) {
      await dismissPrompt();
      toast('没有授权，分组会继续用标题和网址');
      return;
    }
    const { settings: next } = await send('SET_SETTINGS', {
      patch: { autoEnrich: true, enrichGranted: true, enrichPromptDone: true }
    });
    settings = next;
    $('prompt').hidden = true;
    // 立刻补一次，下次分组就能用上；分组本身不受影响
    const { tabs } = await send('GET_TABS', {});
    send('ENRICH_NOW', { tabIds: tabs.map((t) => t.id) }, 60000)
      .then((r) => toast(`已补全 ${r.analyzed} 个页面，下次分组更准`))
      .catch(() => { /* 静默失败即可 */ });
    toast('已开启，正在后台补全');
  } catch (e) {
    toast('开启失败：' + e.message);
  }
}

// ---------------------------------------------------------------- 初始化

async function init() {
  // 弹窗刚打开时，第一次点击有概率被"让窗口获得焦点"吃掉 ——
  // 表现就是"第一行双击没反应，第二行开始正常"。主动 focus 一次可以避开。
  try { window.focus(); } catch (e) { /* 忽略 */ }

  // 不在扩展里（例如直接用浏览器打开本文件）→ 渲染示例数据，只用于看视觉稿
  if (!IS_EXTENSION) {
    $('tabCount').textContent = `${DEMO_TABS.length} 个标签页`;
    renderGroups(DEMO_GROUPS, DEMO_TABS);
    setStatus('设计预览 · 在扩展里运行时会显示真实分组');
    $('btnOrganize').disabled = true;
    $('btnUngroup').disabled = true;
    $('btnOptions').disabled = true;
    return;
  }

  try {
    await send('PING', {}, 3000);
  } catch (e) {
    setStatus('后台未响应。请到 edge://extensions 点一下"重新加载"。');
    $('btnOrganize').disabled = true;
    $('btnUngroup').disabled = true;
    return;
  }

  try {
    const res = await send('GET_SETTINGS', {});
    settings = res.settings;
  } catch (e) { /* 用默认值 */ }

  await refreshCount();
  await maybeShowPrompt();

  $('btnOrganize').addEventListener('click', doOrganize);
  $('btnUngroup').addEventListener('click', doUngroup);
  $('btnOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());
  $('btnEnableEnrich').addEventListener('click', enableEnrich);
  $('btnSkipEnrich').addEventListener('click', dismissPrompt);

  await loadPreview();
}

/**
 * 顶层错误必须显示出来。
 * 脚本一挂就静默留一个空弹窗，用户根本不知道发生了什么
 * （v1.5.0 的设置页就踩过这个坑：一个未定义的函数调用让整页静默失效，
 * 看起来像"我的设置被清空了"）。
 */
function showFatal(err) {
  console.error('[TabTidy 弹窗]', err);
  const box = document.getElementById('fatalBar') || document.createElement('div');
  box.id = 'fatalBar';
  box.className = 'fatal-bar';
  box.textContent = '脚本出错：' + (err && err.message ? err.message : String(err))
    + '　请到 edge://extensions 重新加载本扩展。';
  const wrap = document.querySelector('.wrap');
  if (wrap && !document.getElementById('fatalBar')) wrap.prepend(box);
}

window.addEventListener('error', (e) => showFatal(e.error || e.message));
window.addEventListener('unhandledrejection', (e) => showFatal(e.reason));

init().catch(showFatal);
