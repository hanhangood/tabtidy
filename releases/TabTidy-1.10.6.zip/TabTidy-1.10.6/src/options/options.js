import { DEFAULT_SETTINGS } from '../lib/storage.js';
import { createRulesPanel } from './rules-panel.js';

const $ = (id) => document.getElementById(id);

/** 和弹窗一样：必须带超时，否则后台不回执就会永久挂起 */
function send(type, payload, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error('后台无响应（超过 ' + Math.round(timeoutMs / 1000) + ' 秒）。请到 edge://extensions 重新加载本扩展'));
    }, timeoutMs);
    const finish = (fn) => (arg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(arg);
    };
    try {
      chrome.runtime.sendMessage({ type, payload }, finish((res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!res) return reject(new Error('后台无响应'));
        if (!res.ok) return reject(new Error(res.error));
        resolve(res.data);
      }));
    } catch (e) {
      finish(reject)(e);
    }
  });
}

function toast(msg, ms = 2000) {
  const host = $('toastHost');
  $('toast').textContent = msg;
  host.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { host.hidden = true; }, ms);
}

/** 套件的滑块用 --p（0–100）画已填充部分，需要我们自己同步 */
function syncSliderProgress() {
  const el = $('semanticThreshold');
  const min = Number(el.min), max = Number(el.max), v = Number(el.value);
  const p = max > min ? ((v - min) / (max - min)) * 100 : 0;
  el.style.setProperty('--p', String(Math.round(p * 100) / 100));
}

function fillForm(s) {
  $('collapseGroups').checked = s.collapseGroups;
  $('keepExistingGroups').checked = s.keepExistingGroups;
  $('learning').checked = s.learning;

  $('minTabsPerGroup').value = s.minTabsPerGroup;
  $('maxGroupSize').value = s.maxGroupSize;
  $('semanticThreshold').value = s.semanticThreshold;
  $('semanticThresholdVal').textContent = Number(s.semanticThreshold).toFixed(2);
  syncSliderProgress();
  $('autoEnrich').checked = s.autoEnrich;
  $('syncEnabled').checked = s.syncEnabled !== false;
}

function collectForm() {
  return {
    collapseGroups: $('collapseGroups').checked,
    keepExistingGroups: $('keepExistingGroups').checked,
    learning: $('learning').checked,
    minTabsPerGroup: Number($('minTabsPerGroup').value) || 2,
    maxGroupSize: Number($('maxGroupSize').value) || 12,
    semanticThreshold: Number($('semanticThreshold').value),
    autoEnrich: $('autoEnrich').checked,
    syncEnabled: $('syncEnabled').checked
  };
}

// ---------------------------------------------------------------- 分组顺序（含诊断）
//
// 为什么要把诊断显示出来：以前这一段的失败全被 catch 吞掉，
// 于是"顺序没生效"和"记忆里本来就排错了"在界面上长得一模一样，只能靠猜。
// 现在把记忆、实际顺序、上次整理的结果都摆出来。

async function loadOrderStat() {
  const stat = $('orderStat');
  const diagEl = $('orderDiag');
  if (!stat || !diagEl) return;

  try {
    const info = await send('ORDER_INFO', {}, 8000);

    const mem = info.memory || [];
    stat.textContent = mem.length
      ? '记忆顺序：' + mem.slice(0, 5).join(' › ') + (mem.length > 5 ? ' …（共 ' + mem.length + ' 个）' : '')
      : '还没记过顺序 —— 在弹窗里拖动分组，或者在标签栏里直接拖，就会记住。';

    const nat = (info.native || []).slice(0, 5).join(' › ');
    const bits = [];
    if (nat) bits.push('当前标签栏：' + nat);

    const d = info.diag;
    if (!info.supported) {
      bits.push('⚠️ 这个浏览器没有 tabGroups.move，改不了分组顺序');
    } else if (!d) {
      bits.push('上次整理：还没试过');
    } else if (d.ok) {
      bits.push('上次整理：搬了 ' + d.moved + ' 个 ✓ 顺序已对齐');
    } else {
      bits.push('上次整理：✗ ' + (d.error || '没对齐'));
      if (d.planned) bits.push('计划搬 ' + d.planned + ' 个、实际成功 ' + d.moved + ' 个');
    }
    diagEl.textContent = bits.join(' · ');
  } catch (e) {
    stat.textContent = '顺序信息取不到（' + e.message + '）';
    diagEl.textContent = '';
  }
}

async function applyOrderNow() {
  const btn = $('btnOrderApply');
  btn.disabled = true;
  try {
    let winId;
    try { winId = (await chrome.windows.getCurrent()).id; } catch (e) { /* 交给后台兜底 */ }
    const d = await send('ORDER_APPLY', { windowId: winId }, 25000);
    if (d.ok) toast('已按记忆排好（搬了 ' + d.moved + ' 个分组）');
    else toast('没排好：' + (d.error || '原因未知'));
    await loadOrderStat();
  } catch (e) {
    toast('整理失败：' + e.message);
  } finally {
    btn.disabled = false;
  }
}

// ---------------------------------------------------------------- 跨设备同步
//
// 平时是自动的（后台在数据变化 / 云端变化 / 浏览器启动时各同步一次）。
// 这里只负责显示状态，加一个「同步」按钮用来立刻催一次。

async function loadSyncStat() {
  const el = $('syncStat');
  if (!el) return;
  try {
    const st = await send('SYNC_STATUS', {}, 8000);
    if (!st.available) {
      el.textContent = '这个浏览器不支持扩展云同步';
      return;
    }
    if (st.lastResult && st.lastResult.startsWith('error:')) {
      el.textContent = '⚠️ ' + st.lastResult.slice(6);
      return;
    }
    if (!st.enabled) {
      el.textContent = '已关闭自动同步';
      return;
    }
    const bits = [];
    if (st.lastSyncAt) {
      const d = new Date(st.lastSyncAt);
      bits.push('上次同步 ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'));
    } else {
      bits.push('还没同步过');
    }
    bits.push('这台 ' + st.localRules + ' 条规则');
    if (st.meta) bits.push('云端 ' + (st.meta.rules || 0) + ' 条');
    bits.push('配额 ' + Math.round(st.used / 1024) + ' / ' + Math.round(st.quota / 1024) + ' KB');
    el.textContent = bits.join(' · ');
  } catch (e) {
    el.textContent = '同步状态取不到（' + e.message + '）';
  }
}

async function syncNow() {
  const btn = $('btnSyncNow');
  btn.disabled = true;
  try {
    const r = await send('SYNC_NOW', {}, 25000);
    if (!r.ok) throw new Error(r.error || r.reason || '同步失败');

    if (r.reason === 'unchanged') toast('已经是最新的');
    else if (r.reason === 'both') toast('双向合并完成：' + r.rules + ' 条规则');
    else if (r.pushed) toast('已上传 ' + r.rules + ' 条规则');
    else if (r.pulled) toast('已从云端取回 ' + r.rules + ' 条规则');
    else toast('同步完成');

    if (r.pulled) {
      // 云端覆盖了本地，表单和规则表要跟着刷新
      const res = await send('GET_SETTINGS', {});
      fillForm(res.settings);
      await loadLearning().catch(() => {});
    }
    await loadSyncStat();
  } catch (e) {
    toast('同步失败：' + e.message);
  } finally {
    btn.disabled = false;
  }
}

// ---------------------------------------------------------------- 自动保存
//
// 以前三个勾选框只读不写：勾完必须再点一次「保存设置」，不点就白勾了。
// 对不熟悉技术的用户来说这是个标准的坑，所以改成**改动即保存**。
//
// ⚠️ 最关键的一条：必须在 boot() 成功之后才允许写。
//    否则页面刚打开、表单还是 HTML 默认值时用户随手点一下，
//    就把存储里的真实设置覆盖成默认值了 —— 那才是真的丢数据。

let formReady = false;     // boot() 成功读到设置后才置 true
let autoSaveTimer = null;

function setSaveStat(text) {
  const el = $('saveStat');
  if (el) el.textContent = text || '';
}

async function flushSave() {
  autoSaveTimer = null;
  if (!formReady) {
    setSaveStat('设置还没载入完成，这次改动没有保存');
    return;
  }
  try {
    await send('SET_SETTINGS', { patch: collectForm() });
    setSaveStat('已自动保存 ' + new Date().toLocaleTimeString('zh-CN'));
  } catch (e) {
    setSaveStat('保存失败：' + e.message);
    toast('保存失败：' + e.message);
  }
}

/** 输入框和滑块连续改动时不要每一下都写一次存储 */
function scheduleAutoSave() {
  if (autoSaveTimer) clearTimeout(autoSaveTimer);
  setSaveStat('正在保存…');
  autoSaveTimer = setTimeout(flushSave, 350);
}

async function reset() {
  if (!confirm('恢复为默认设置？分组规则不会被清除。')) return;
  const res = await send('SET_SETTINGS', { patch: structuredClone(DEFAULT_SETTINGS) });
  fillForm(res.settings);
  setSaveStat('已恢复默认');
  toast('已恢复默认');
}

async function loadMetaStat() {
  try {
    const { cached, permGranted } = await send('META_STATS', {});
    const bits = [cached ? `已缓存 ${cached} 个页面` : '缓存为空'];
    if (!permGranted) bits.push('（尚未授权读取网页内容）');
    $('metaStat').textContent = '　' + bits.join('');
  } catch (e) { /* 忽略 */ }
}

async function loadLearning() {
  const { learning } = await send('GET_LEARNING', {});
  const items = Object.entries(learning.domainMap || {});
  const mine = items.filter(([, v]) => v && v.origin === 'truth').length;
  const auto = items.length - mine;
  // 权重 < 2 的还没真正参与分组（applyLearned 的 minCount 是 2），
  // 所以标题不能叫"已生效的规则"，得把这一批数出来
  const pending = items.filter(([, v]) => ((v && v.count) || 0) < 2).length;

  $('learnStat').textContent = items.length
    ? `共 ${items.length} 条：${mine} 条你设的，${auto} 条自动学的`
      + (pending ? ` · 其中 ${pending} 条还没生效（只观察到 1 次，需要 2 次）` : '')
    : '还没有规则。打开「设置分组规则」可以手动设，或者直接把标签页拖进某个组，扩展会自动学。';
  const box = $('learnBox');
  const wrap = $('learnBoxWrap');
  if (!items.length) {
    box.innerHTML = '';
    if (wrap) wrap.hidden = true;
    return;
  }
  if (wrap) wrap.hidden = false;
  const list = items.sort((a, b) => b[1].last - a[1].last).slice(0, 50);
  let html = '<table class="rule-table"><thead><tr><th>网站</th><th>归到的组</th><th>来源</th><th class="num">权重</th><th>最近</th><th></th></tr></thead><tbody>';
  for (const [host, v] of list) {
    // 两种来源必须用**不同的词**，而且要和上面那行统计用的是同一套说法：
    //   你设的   = 你亲手打出组名（标注面板 / 弹窗双击改名），系统不参与推断
    //   自动学的 = 系统看你把标签页拖进某组、或改了分组标题，自己推断出来的
    const origin = v.origin === 'truth'
      ? '<span class="s-chip s-chip--blue chip-sm" title="你亲手填的组名（在「让分组听你的」里标注，或双击组名改的）。系统不会改它">你设的</span>'
      : '<span class="s-chip s-chip--grey chip-sm" title="系统观察你把标签页拖进这个组、或改了分组标题，自己推断出来的">自动学的</span>';
    // 每条后面挂一个删除：老版本把规则按根域名记了（qq.com 会连带 QQ邮箱），
    // 那种宽规则只能靠用户自己指出来删掉，再重新标一次。
    const count = (v && v.count) || 0;
    // 权重 < 2 的还不参与分组，得在表格里直接标出来，别让人以为它已经生效
    const countCell = count >= 2
      ? String(count)
      : `${count}<span class="faint"> 未生效</span>`;
    html += `<tr><td class="mono">${host}</td><td>${v.name}</td><td>${origin}</td>`
      + `<td class="num">${countCell}</td><td class="faint">${new Date(v.last).toLocaleDateString('zh-CN')}</td>`
      + `<td><button class="s-btn s-btn--text" data-del="${host}" title="删掉这条规则">删除</button></td></tr>`;
  }
  html += '</tbody></table>';
  box.innerHTML = html;
}

// ---------------------------------------------------------------- 启动

/**
 * 顶层错误必须暴露到界面上。
 * 脚本一挂就静默留一张空表单，是最坏的表现形式——用户会以为"我的设置被清空了"，
 * 而实际上数据好好的。（v1.5.0 就踩过这个坑：一个未定义的函数调用让整页静默失效。）
 */
function showFatal(err) {
  console.error('[TabTidy 设置页]', err);
  let bar = document.getElementById('fatalBar');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'fatalBar';
    bar.className = 'fatal-bar';
    (document.querySelector('.page') || document.body).prepend(bar);
  }
  bar.textContent = '设置页脚本出错：' + (err && err.message ? err.message : String(err))
    + '。你的设置数据没有被改动。请到 edge://extensions 重新加载本扩展。';
}

function bindUI() {
  // ---- 所有普通控件：改动即保存 ----
  for (const id of ['collapseGroups', 'keepExistingGroups', 'learning', 'minTabsPerGroup', 'maxGroupSize']) {
    $(id).addEventListener('change', scheduleAutoSave);
  }
  $('semanticThreshold').addEventListener('input', (e) => {
    $('semanticThresholdVal').textContent = Number(e.target.value).toFixed(2);
    syncSliderProgress();
    scheduleAutoSave();
  });
  $('semanticThreshold').addEventListener('change', scheduleAutoSave);

  $('autoEnrich').addEventListener('change', async (e) => {
    // 权限申请必须由扩展页面在用户手势里发起
    if (e.target.checked) {
      const granted = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] });
      if (!granted) {
        e.target.checked = false;
        toast('没有授权，分组会继续用标题和网址');
        loadMetaStat();
        return;
      }
      // 只写权限标记；autoEnrich 本身的值走下面统一的自动保存
      await send('SET_SETTINGS', { patch: { enrichGranted: true, enrichPromptDone: true } });
      toast('已开启');
    }
    scheduleAutoSave();
    loadMetaStat();
  });

  // 「让分组听你的」用本页内的模态弹窗，不再新开标签页
  const rulesPanel = createRulesPanel({
    dialog: $('rulesDialog'),
    send,
    toast,
    onChanged: async () => {
      await loadLearning().catch(() => {});
      // 写入规则时可能自动打开了「记住我的分组习惯」，把开关同步过来
      try {
        const res = await send('GET_SETTINGS', {});
        $('learning').checked = res.settings.learning;
      } catch (e) { /* 忽略 */ }
    }
  });

  $('btnRules').addEventListener('click', () => rulesPanel.open());
  $('btnReset').addEventListener('click', reset);
  // 规则表的按条删除（委托，避免每次重绘都重复绑）
  $('learnBox').addEventListener('click', async (e) => {
    const btn = e.target && e.target.closest ? e.target.closest('[data-del]') : null;
    if (!btn) return;
    const key = btn.getAttribute('data-del');
    if (!key) return;
    if (!confirm(`删掉「${key}」这条规则？\n\n删掉之后，这个网站下次分组会回到自动判断。`)) return;
    btn.disabled = true;
    try {
      const r = await send('DELETE_RULES', { keys: [key] }, 10000);
      toast(r.removed ? '已删除 1 条规则' : '没找到这条规则');
      await loadLearning().catch(() => {});
    } catch (err) {
      toast('删除失败：' + err.message);
      btn.disabled = false;
    }
  });

  $('btnOrderApply').addEventListener('click', applyOrderNow);
  $('btnSyncNow').addEventListener('click', syncNow);
  // 开关本身走统一的自动保存；后台监听到改动会自动同步一次
  $('syncEnabled').addEventListener('change', scheduleAutoSave);
  $('btnClearMeta').addEventListener('click', async () => {
    await send('CLEAR_META_CACHE', {});
    await loadMetaStat();
    toast('页面内容缓存已清空');
  });
  $('btnClearLearning').addEventListener('click', async () => {
    if (!confirm('清空所有分组规则和习惯？此操作不可撤销。')) return;
    await send('CLEAR_LEARNING', {});
    await loadLearning().catch(() => {});
    toast('已清空');
  });
}

/**
 * 把用户真实的设置填进表单，然后才允许写入。
 * formReady 这个闸门很重要：读成功之前不允许保存，免得用空表单覆盖真实设置。
 */
async function boot() {
  const res = await send('GET_SETTINGS', {});
  fillForm(res.settings);
  formReady = true;
  setSaveStat('改动会自动保存');
  await loadLearning().catch((e) => console.warn('[TabTidy] 规则表载入失败', e));
  await loadMetaStat();
  await loadOrderStat();
  await loadSyncStat();
}

// 兜底：任何未捕获的错误都显示出来，不要静默失败
window.addEventListener('error', (e) => showFatal(e.error || e.message));
window.addEventListener('unhandledrejection', (e) => showFatal(e.reason));

// 绑事件和取设置各自独立兜错：一边挂了不能拖累另一边
try {
  bindUI();
} catch (e) {
  showFatal(e);
}
boot().catch(showFatal);
