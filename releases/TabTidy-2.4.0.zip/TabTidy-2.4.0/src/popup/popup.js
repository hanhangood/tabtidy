// 弹窗：只有一个按钮。
// 没有任何策略选择、没有评分、没有 AI —— 分组方式固定为「智能分组」。

const $ = (id) => document.getElementById(id);

// 只有真正在扩展里跑时才走消息通道。直接在浏览器里打开本文件时走下面的示例数据，
// 方便查看视觉稿、也方便调试样式。
const IS_EXTENSION = location.protocol === 'chrome-extension:';

const DEMO_TABS = [
  { id: 1, title: 'ofa-order-system - Pull requests', url: 'https://github.com/u/ofa-order-system/pulls', domain: 'github.com' },
  { id: 2, title: 'Element Plus 表格组件 Table', url: 'https://element-plus.org/zh-CN/component/table.html', domain: 'element-plus.org' },
  { id: 3, title: 'Vue 3 组合式 API 文档', url: 'https://cn.vuejs.org/guide/extras/composition-api-faq.html', domain: 'vuejs.org' },
  { id: 4, title: '机械键盘 87键 - 京东', url: 'https://item.jd.com/100012043978.html', domain: 'jd.com' },
  { id: 5, title: '键帽 PBT 套装 - 淘宝', url: 'https://item.taobao.com/item.htm?id=123456', domain: 'taobao.com' },
  { id: 6, title: '今天天气怎么样', url: 'https://weather.example.com/today', domain: 'weather.example.com' }
];
const DEMO_GROUPS = [
  { key: 'd1', name: '订单系统', color: 'blue', source: 'domain', confidence: 0.9, tabIds: [1] },
  { key: 'd2', name: '前端项目', color: 'purple', source: 'domain', confidence: 0.9, tabIds: [2, 3] },
  { key: 'd3', name: '购物与电商', color: 'orange', source: 'topic', confidence: 0.85, tabIds: [4, 5] },
  { key: 'd4', name: 'example.com', color: 'grey', source: 'domain', confidence: 0.95, tabIds: [6] }
];

const STRATEGY = 'hybrid';
let settings = null;
let currentResult = null;

/**
 * 给消息加超时。没有这层保护，只要后台回执没回来，按钮就会永远转圈。
 */
function send(type, payload, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error('后台无响应（超过 ' + Math.round(timeoutMs / 1000) + ' 秒）。请再点一次，或到 edge://extensions 重新加载本扩展'));
    }, timeoutMs);

    const finish = (fn) => (arg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(arg);
    };

    try {
      chrome.runtime.sendMessage({ type, payload }, finish((res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!res) return reject(new Error('后台无响应'));
        if (!res.ok) return reject(new Error(res.error));
        resolve(res.data);
      }));
    } catch (e) {
      finish(reject)(e);
    }
  });
}

function toast(msg, ms = 1800) {
  const host = $('toastHost');
  $('toast').textContent = msg;
  host.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { host.hidden = true; }, ms);
}

function setStatus(text) {
  $('status').textContent = text || '';
}

// ---------------------------------------------------------------- 结果列表

// v2.3.4 起没有「其他 / 兜底」这一类组了：剩下没构成主题的零散页面会**按网站各自成组**。
// 所以这一行的右侧只剩下关闭和展开两个操作，不再需要来源 Chip。

function svgUse(id, cls) {
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', cls);
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS(NS, 'use');
  use.setAttribute('href', id);
  svg.appendChild(use);
  return svg;
}

/** 一行的副标题：几个标签页 */
function subtitleFor(g) {
  return g.tabIds.length + ' 个标签页';
}

/**
 * 关掉一整个分组：把组里所有标签页都关掉。
 *
 * **不可撤销**，所以先问一句。`window.confirm` 在扩展弹窗里是可用的；
 * 拿不到（比如测试环境）就当作"确认"——真正的拦截在后台的 `tabs.remove` 权限上。
 */
async function closeGroup(g) {
  const ids = (g.tabIds || []).filter((id) => Number.isInteger(id));
  if (!ids.length) {
    toast('这一组里没有标签页');
    return;
  }

  const msg = `关闭「${g.name}」里的 ${ids.length} 个标签页？\n\n关掉之后不能恢复。`;
  const ask = typeof window !== 'undefined' && typeof window.confirm === 'function'
    ? window.confirm.bind(window)
    : (typeof confirm === 'function' ? confirm : null);
  if (ask && !ask(msg)) return;

  try {
    const r = await send('CLOSE_GROUP', { tabIds: ids }, 15000);
    toast(r.closed ? `已关闭 ${r.closed} 个标签页` : '没关掉任何标签页');
    await loadPreview();
  } catch (e) {
    toast('关闭失败：' + e.message);
  }
}

// ---------------------------------------------------------------- 置顶分组
//
// **只支持一个操作：把某个分组拖到最上面 → 它成为"置顶"，下次分组/刷新后还在第一位。**
// 其余分组的先后不做任何要求，所以这里不记整张顺序表，只记一个名字。

let dragEl = null;      // 正在拖的行
let markEl = null;      // 当前显示插入线的行
let lastGroups = [];    // 上一次渲染的分组

function clearDropMark() {
  if (markEl) {
    markEl.classList.remove('drop-before', 'drop-after');
    markEl = null;
  }
}

async function pinGroup(name) {
  const g = lastGroups.find((x) => x.name === name);
  // 顺手记下这个组里的网站：组名以后变了（算法升级换映射）也能靠它认出来
  const hosts = g
    ? [...new Set((g.tabs || []).map((t) => t.host || t.domain).filter(Boolean))]
    : [];

  let winId;
  try {
    const w = await chrome.windows.getCurrent();
    winId = w && w.id;
  } catch (e) { /* 交给后台兜底 */ }

  try {
    const r = await send('SET_PIN', { name, hosts, windowId: winId }, 15000);
    toast(r.ok ? '已置顶：' + name : '置顶没生效：' + (r.error || '原因未知'));
  } catch (e) {
    toast('置顶失败：' + e.message);
  }
  await loadPreview();
}

function bindDrag(wrap) {
  wrap.addEventListener('dragstart', (e) => {
    // 行内输入框（如果有）里拖选文字时不应该触发整行拖动
    if (e.target && e.target.tagName === 'INPUT') { e.preventDefault(); return; }
    dragEl = wrap;
    wrap.classList.add('is-dragging');
    if (e.dataTransfer) {
      e.dataTransfer.effectAllowed = 'move';
      try { e.dataTransfer.setData('text/plain', wrap.dataset.groupName || ''); } catch (err) { /* 忽略 */ }
    }
  });

  wrap.addEventListener('dragend', () => {
    wrap.classList.remove('is-dragging');
    clearDropMark();
    dragEl = null;
  });

  wrap.addEventListener('dragover', (e) => {
    if (!dragEl || dragEl === wrap) return;
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
    const rect = wrap.getBoundingClientRect ? wrap.getBoundingClientRect() : null;
    const after = rect ? (e.clientY - rect.top) > rect.height / 2 : true;
    clearDropMark();
    wrap.classList.add(after ? 'drop-after' : 'drop-before');
    markEl = wrap;
  });

  wrap.addEventListener('dragleave', () => {
    if (markEl === wrap) clearDropMark();
  });

  wrap.addEventListener('drop', (e) => {
    e.preventDefault();
    if (!dragEl || dragEl === wrap) { clearDropMark(); return; }

    const after = wrap.classList.contains('drop-after');
    const to = Number(wrap.dataset.index);
    clearDropMark();
    if (!Number.isFinite(to)) return;

    // 只有"落在第一行之前"才是一个有意义的操作 —— 那是"拖到最上面"。
    // 拖到中间/底部不做任何事：其余分组的先后本来就没有要求。
    if (after || to !== 0) {
      toast('把想要的那个组拖到最上面就行');
      loadPreview().catch(() => {});
      return;
    }
    pinGroup(dragEl.dataset.groupName || '');
  });
}

function renderGroups(groups, tabs) {
  lastGroups = groups;          // 拖动排序要用当前这份顺序
  const box = $('results');
  const empty = $('empty');
  box.innerHTML = '';
  const tabMap = new Map(tabs.map((t) => [t.id, t]));

  if (!groups.length) {
    box.hidden = true;
    empty.hidden = false;
    return;
  }
  box.hidden = false;
  empty.hidden = true;

  for (const [gi, g] of groups.entries()) {
    const wrap = document.createElement('li');
    wrap.className = 'popup__row';
    wrap.draggable = true;
    wrap.dataset.index = String(gi);
    wrap.dataset.groupName = g.name;

    // ---- 分组行：色点 + 标题/副标题 + 关闭/展开 ----
    // 刻意**不加** data-pressable：套件对它的按下规则是"整行变蓝 + 文字刷白"，
    // 连点两下会闪两次。按下反馈交给 ui.css 里更轻的那档。
    const row = document.createElement('div');
    row.className = 's-list-item popup__group';

    const dot = document.createElement('span');
    dot.className = 'popup__dot popup__dot--' + (g.color || 'grey');
    row.appendChild(dot);

    const text = document.createElement('div');
    text.className = 's-list-item__text';
    const title = document.createElement('div');
    title.className = 's-list-item__title';
    title.textContent = g.name;
    title.title = '组名由 TabTidy 按网址自动决定 · 拖到最上面可置顶';
    const sub = document.createElement('div');
    sub.className = 's-list-item__subtitle';
    sub.textContent = subtitleFor(g);
    text.append(title, sub);
    row.appendChild(text);

    const detail = document.createElement('div');
    detail.className = 's-list-item__detail';
    // 关闭整组。
    // ⚠️ 这会真的关掉组里所有标签页，所以先 confirm 一道。
    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 's-btn s-btn--text popup__close-btn';
    closeBtn.title = '关闭这个分组（会关掉组里所有标签页）';
    closeBtn.setAttribute('aria-label', '关闭分组 ' + g.name);
    closeBtn.appendChild(svgUse('#si-close', 's-icon s-icon--16 popup__close-icon'));
    // 三个事件都要挡：mousedown 不挡的话，行的 draggable 会先吃掉这次按下，
    // click 就永远不来了；click 不挡的话，会顺带把这一行展开/收起。
    for (const ev of ['mousedown', 'pointerdown', 'click']) {
      closeBtn.addEventListener(ev, (e) => e.stopPropagation());
    }
    closeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      closeGroup(g);
    });
    detail.appendChild(closeBtn);

    // 箭头单独一个类：展开时的旋转只该作用在它身上。
    // 用泛化的 .s-icon--16 会把同一行里的「×」也转 180°（× 转过来就变成 + 了）。
    detail.appendChild(svgUse('#si-chevron-down', 's-icon s-icon--16 popup__chev'));
    row.appendChild(detail);

    // ---- 展开后的标签页行（套件的 List Tile 3 形态，自己做成嵌套行） ----
    const tabsBox = document.createElement('div');
    tabsBox.className = 'popup__tabs';
    tabsBox.hidden = true;

    for (const id of g.tabIds) {
      const t = tabMap.get(id);
      if (!t) continue;
      const tr = document.createElement('div');
      tr.className = 's-list-item popup__tab';

      const ttl = document.createElement('div');
      ttl.className = 's-list-item__title';
      ttl.textContent = t.title || t.url;
      ttl.title = t.url;

      const dm = document.createElement('div');
      dm.className = 's-list-item__subtitle';
      dm.textContent = t.domain;

      tr.append(ttl, dm);
      tr.addEventListener('click', async () => {
        try {
          await chrome.tabs.update(id, { active: true });
          const tab = await chrome.tabs.get(id);
          await chrome.windows.update(tab.windowId, { focused: true });
          window.close();
        } catch (e) { toast('标签页已关闭'); }
      });
      tabsBox.appendChild(tr);
    }

    row.addEventListener('click', () => {
      const open = row.classList.toggle('is-open');
      tabsBox.hidden = !open;
    });

    bindDrag(wrap);

    wrap.append(row, tabsBox);
    box.appendChild(wrap);
  }
}

// ---------------------------------------------------------------- 主操作

async function refreshCount() {
  try {
    const { tabs } = await send('GET_TABS', {});
    $('tabCount').textContent = tabs.length ? `${tabs.length} 个标签页` : '';
  } catch (e) {
    $('tabCount').textContent = '';
  }
}

async function loadPreview() {
  try {
    const res = await send('PREVIEW', { strategy: STRATEGY, overrides: {} });
    currentResult = { groups: res.groups, tabs: res.tabs };
    renderGroups(res.groups, res.tabs);
  } catch (e) {
    setStatus('预览失败：' + e.message);
  }
}

/** 唯一的主操作：分组 + 落地。 */
async function doOrganize() {
  const btn = $('btnOrganize');
  btn.disabled = true;
  setStatus('正在分组…');
  try {
    const res = await send('ORGANIZE', { strategy: STRATEGY, overrides: {} });
    const applied = res.applied || [];
    const alreadyOk = res.alreadyOk || [];
    const failed = res.failed || [];

    if (applied.length) {
      setStatus(`已建好 ${applied.length} 个分组，共 ${applied.reduce((s, a) => s + a.count, 0)} 个标签页`);
    } else if (alreadyOk.length) {
      setStatus('分组已是最新，无需改动');
    } else {
      setStatus('没有需要变更的分组');
    }
    if (failed.length) setStatus(`有 ${failed.length} 组没成功：` + failed.map((f) => f.name).join('、'));

    const list = (res.tabs && res.tabs.length) ? res.tabs : (currentResult?.tabs || []);
    currentResult = { groups: res.groups || [], tabs: list };
    renderGroups(res.groups || [], list);
  } catch (e) {
    setStatus('失败：' + e.message);
  } finally {
    btn.disabled = false;
  }
}

async function doUngroup() {
  try {
    const res = await send('UNGROUP_ALL', {});
    setStatus(`已取消 ${res.ungrouped} 个标签页的分组`);
    $('results').innerHTML = '';
    currentResult = null;
  } catch (e) {
    setStatus('失败：' + e.message);
  }
}

// ---------------------------------------------------------------- 初始化

async function init() {
  // 弹窗刚打开时，第一次点击有概率被"让窗口获得焦点"吃掉 ——
  // 表现就是"第一下点不动，后面才正常"。主动 focus 一次可以避开。
  try { window.focus(); } catch (e) { /* 忽略 */ }

  // 不在扩展里（例如直接用浏览器打开本文件）→ 渲染示例数据，只用于看视觉稿
  if (!IS_EXTENSION) {
    $('tabCount').textContent = `${DEMO_TABS.length} 个标签页`;
    renderGroups(DEMO_GROUPS, DEMO_TABS);
    setStatus('设计预览 · 在扩展里运行时会显示真实分组');
    $('btnOrganize').disabled = true;
    $('btnUngroup').disabled = true;
    $('btnOptions').disabled = true;
    return;
  }

  try {
    await send('PING', {}, 3000);
  } catch (e) {
    setStatus('后台未响应。请到 edge://extensions 点一下"重新加载"。');
    $('btnOrganize').disabled = true;
    $('btnUngroup').disabled = true;
    return;
  }

  try {
    const res = await send('GET_SETTINGS', {});
    settings = res.settings;
  } catch (e) { /* 用默认值 */ }

  await refreshCount();

  $('btnOrganize').addEventListener('click', doOrganize);
  $('btnUngroup').addEventListener('click', doUngroup);
  $('btnOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());

  await loadPreview();
}

/**
 * 顶层错误必须显示出来。
 * 脚本一挂就静默留一个空弹窗，用户根本不知道发生了什么
 * （v1.5.0 的设置页就踩过这个坑：一个未定义的函数调用让整页静默失效，
 * 看起来像"我的设置被清空了"）。
 */
function showFatal(err) {
  console.error('[TabTidy 弹窗]', err);
  const box = document.getElementById('fatalBar') || document.createElement('div');
  box.id = 'fatalBar';
  box.className = 'fatal-bar';
  box.textContent = '脚本出错：' + (err && err.message ? err.message : String(err))
    + '　请到 edge://extensions 重新加载本扩展。';
  const wrap = document.querySelector('.wrap');
  if (wrap && !document.getElementById('fatalBar')) wrap.prepend(box);
}

window.addEventListener('error', (e) => showFatal(e.error || e.message));
window.addEventListener('unhandledrejection', (e) => showFatal(e.reason));

init().catch(showFatal);
